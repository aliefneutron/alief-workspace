(()=>{
 if(window!==window.top||!['dola.com','www.dola.com'].includes(location.hostname))return;
 let timer;const seen=new Set();
 function scan(force=false){if(force)seen.clear();let count=0;for(const script of document.querySelectorAll('script:not([src]),[data-fallback-api]')){const text=script.getAttribute('data-fallback-api')?JSON.stringify({fallback_api:script.getAttribute('data-fallback-api')}):script.textContent;if(!text||text.length>4*1024*1024)continue;for(const item of AliefDolaScan.scan(text)){if(seen.has(item.fallbackUrl))continue;seen.add(item.fallbackUrl);count++;window.postMessage({type:'NEUTRON_RESOLVE_FALLBACK',...item},location.origin);}}window.postMessage({type:'ALIEF_DOLA_BOOTSTRAP_STATUS',count},location.origin);}
 window.addEventListener('message',event=>{if(event.source===window&&event.data?.type==='ALIEF_DOLA_RESCAN_BOOTSTRAP')scan(true);});
 const observer=new MutationObserver(mutations=>{if(!mutations.some(m=>[...m.addedNodes].some(n=>n.nodeName==='SCRIPT')))return;clearTimeout(timer);timer=setTimeout(()=>scan(),200);});observer.observe(document,{childList:true,subtree:true});if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',()=>scan(),{once:true});else scan();
})();
