'use strict';
// Keep session headers only in extension memory. Never expose them to the page or logs.
const sessionHeaders=new Map();
const domains=['dola.com','byteintlapi.com','ibytedtos.com','byteoversea.com','byteimg.com','ibytedtos.cn','volccdn.com','doubaocdn.com','bytecdn.cn','bytescm.com','volces.com'];
const filters={urls:domains.map(d=>'https://*.'+d+'/*')};
const capturedSources=new Map(),captureStats=new Map();
function captureBatch(tabId,text,context={}){if(!globalThis.AliefDolaScan)return;const items=AliefDolaScan.scan(text,context);if(!items.length)return;let cache=capturedSources.get(tabId);if(!cache){cache=new Map();capturedSources.set(tabId,cache);}for(const item of items){const prev=cache.get(item.fallbackUrl);if(prev?.meta?.chatId&&!item.meta?.chatId)item.meta={...item.meta,chatId:prev.meta.chatId};cache.set(item.fallbackUrl,item);}while(cache.size>100)cache.delete(cache.keys().next().value);if(capturedSources.size>20)capturedSources.delete(capturedSources.keys().next().value);browser.tabs.sendMessage(tabId,{type:'ALIEF_DOLA_CAPTURE',items,channel:'network'}).catch(()=>{});}
if(browser.webRequest.onBeforeRequest&&browser.webRequest.filterResponseData){browser.webRequest.onBeforeRequest.addListener(details=>{
 if(details.tabId<0||!allowed(details.url)||!['main_frame','xmlhttprequest'].includes(details.type)||(!site(details.url)&&!site(details.documentUrl)&&!site(details.originUrl)))return;
 if(/\.(?:mp4|webm|png|jpe?g|gif|webp|woff2?|css|js)(?:\?|$)/i.test(details.url))return;
 let filter;try{filter=browser.webRequest.filterResponseData(details.requestId);}catch{return;}
 const stat=captureStats.get(details.tabId)||{responses:0,filter:true};stat.responses++;captureStats.set(details.tabId,stat);
 const context={};try{const u=new URL(details.url);context.chat_id=u.searchParams.get('chat_id')||u.searchParams.get('conversation_id')||u.pathname.match(/\/chat\/([^/?]+)/)?.[1]||'';const body=details.requestBody;if(body?.raw){const payload=JSON.parse(new TextDecoder().decode(body.raw[0].bytes));const getId=(n,d=0)=>{if(!n||typeof n!=='object'||d>4)return '';for(const k of ['conversation_short_id','conversationShortId','chat_id','conversation_id','conversationId','chatId'])if(typeof n[k]==='string'&&n[k])return n[k];for(const k of ['data','body','conversation','conversation_info','request']){const id=getId(n[k],d+1);if(id)return id;}return '';};context.chat_id=getId(payload)||context.chat_id;}else if(body?.formData)context.chat_id=body.formData.chat_id?.[0]||body.formData.conversation_id?.[0]||context.chat_id;}catch{}
 const decoder=new TextDecoder();let buffer='',size=0,last=0;
 filter.ondata=event=>{filter.write(event.data);try{size+=event.data.byteLength;buffer+=decoder.decode(event.data,{stream:true});if(buffer.length>4*1024*1024)buffer=buffer.slice(-128*1024);if(size-last>8192&&/fallback_api|fallbackApi/.test(buffer.slice(-128*1024))){captureBatch(details.tabId,buffer.slice(-128*1024),context);last=size;}}catch{}};
 filter.onstop=()=>{try{buffer+=decoder.decode();captureBatch(details.tabId,buffer,context);}finally{filter.close();}};
 filter.onerror=()=>{try{filter.disconnect();}catch{}};
},filters,['blocking','requestBody']);}
function site(raw){try{const u=new URL(raw);return u.protocol==='https:'&&!u.username&&!u.password&&['dola.com','www.dola.com'].includes(u.hostname);}catch{return false;}}
function allowed(raw){try{const u=new URL(raw);return ['http:','https:'].includes(u.protocol)&&!u.username&&!u.password&&!u.port&&domains.some(d=>u.hostname===d||u.hostname.endsWith('.'+d));}catch{return false;}}
browser.webRequest.onBeforeSendHeaders.addListener(details=>{
 if(details.tabId<0||!allowed(details.url))return;
 const host=new URL(details.url).hostname;const headers={};
 for(const entry of details.requestHeaders||[]){const name=entry.name.toLowerCase();if(['cookie','user-agent','accept-language'].includes(name)&&typeof entry.value==='string'&&entry.value.length<=32768&&!/[\r\n]/.test(entry.value))headers[name]=entry.value;}
 let context=sessionHeaders.get(details.tabId);if(!context){context=new Map();sessionHeaders.set(details.tabId,context);}context.set(host,headers);
 if(context.size>40)context.delete(context.keys().next().value);
 if(sessionHeaders.size>20)sessionHeaders.delete(sessionHeaders.keys().next().value);
},filters,['requestHeaders']);
browser.runtime.onMessage.addListener((message,sender)=>{
 if(message?.type==='ALIEF_DOLA_CAPTURE_POLL'){
  if(!sender.tab||sender.frameId!==0||!site(sender.url))return Promise.resolve({error:'Dola only'});
  return Promise.resolve({items:[...(capturedSources.get(sender.tab.id)||new Map()).values()],stats:captureStats.get(sender.tab.id)||{responses:0,filter:!!browser.webRequest.filterResponseData}});
 }
 if(message?.type!=='ALIEF_DOLA_NETWORK_CONTEXT')return;
 if(!sender.tab||sender.frameId!==0||!site(sender.url)||!allowed(message.url))return Promise.resolve({error:'Dola only'});
 const context=sessionHeaders.get(sender.tab.id)||new Map();
 const host=new URL(message.url).hostname;
 return Promise.resolve({hosts:{[host]:context.get(host)||{}}});
});
