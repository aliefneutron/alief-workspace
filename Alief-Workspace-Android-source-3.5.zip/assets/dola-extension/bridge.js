'use strict';

if(window===window.top&&location.protocol==='https:'&&['dola.com','www.dola.com'].includes(location.hostname)){
 let lastDolaError='';
 const currentChat=()=>location.pathname.match(/\/chat\/([^/?]+)/)?.[1]||'';
 let canUseMedia=()=>false;
 const within=(promise,ms,stage)=>new Promise((resolve,reject)=>{const timer=setTimeout(()=>reject(Error('Waktu tunggu habis ['+stage+']. Coba lagi atau salin Diagnostik Dola.')),ms);Promise.resolve(promise).then(value=>{clearTimeout(timer);resolve(value);},error=>{clearTimeout(timer);reject(error);});});
 const invoke=async(action,extra={})=>{
  if(action==='fetch'||action==='download'||action==='preview'){
   let session;try{session=await within(browser.runtime.sendMessage({type:'ALIEF_DOLA_NETWORK_CONTEXT',url:extra.url}),1500,'DOLA_CONTEXT');}catch{}
   if(!session||session.error)session={hosts:{}};
   extra={...extra,networkContext:session,userAgent:navigator.userAgent,referrer:location.origin+'/'};
  }
  try{let response=await within(browser.runtime.sendNativeMessage('aliefDola',{action,...extra}),action==='download'?245000:(action==='fetch'?12000:4000),'DOLA_NATIVE_'+action.toUpperCase());if(typeof response==='string')response=JSON.parse(response);if(action==='fetch')browser.runtime.sendNativeMessage('aliefDola',{action:'diagnostic',stage:'native_fetch_received'}).catch(()=>{});if(!response||response.error)throw Error(response?.error||'Integrasi Dola belum siap.');return response.value;}catch(error){lastDolaError=error.message;throw error;}
 };

 let lastTheme='',lastThemeKey='',themeFailures=0;
 const THEMES={green:{name:'green',bg:'#101319',card:'#1b212b',accent:'#cfff72'},burgundy:{name:'burgundy',bg:'#230d17',card:'#45172b',accent:'#ff779e'}};
 function themeCss(t){const bg=t.bg,card=t.card,accent=t.accent;return `
 #dp-root{--dp-glass:${card} !important;--dp-glass-hi:${card} !important;--dp-border:${accent}66 !important;--dp-border-soft:${accent}33 !important;--dp-text:#fff !important;--dp-muted:#d8dce3 !important;--dp-ok:${accent} !important;--dp-grad:linear-gradient(135deg,${accent},${accent}) !important;}
 #dp-root .dp-panel,#dp-root .dp-pill{background:${bg} !important;border-color:${accent}88 !important;box-shadow:0 12px 30px #0008 !important}
 #dp-root .dp-glass,#dp-root .dp-header,#dp-root .dp-video-item,#dp-root .dp-ghost-btn,#dp-root .dp-icon-btn,#dp-root .dp-empty-state{background:${card} !important;border-color:${accent}55 !important}
 #dp-root .dp-video-item:hover,#dp-root .dp-ghost-btn:hover,#dp-root .dp-icon-btn:hover{background:${accent}22 !important;border-color:${accent}aa !important}
 #dp-root .dp-thumb{background:${bg} !important;border-color:${accent}66 !important;color:${accent} !important}
 #dp-root .dp-orb{display:none !important}
 #dp-root .dp-primary-btn,#dp-root .dp-pill-count,#dp-root .dp-switch input:checked+.dp-slider{background:${accent} !important;color:${bg} !important;box-shadow:none !important;border-color:${accent} !important}
 #dp-root .dp-primary-btn.dp-ok{background:#34d399 !important;color:#052e1f !important}
 #dp-root .dp-primary-btn.dp-err{background:#f87171 !important;color:#3b0a0a !important}
 #dp-root .dp-slider{background:#ffffff33 !important;border-color:${accent}44 !important}
 #dp-root .dp-num{color:${accent} !important;background:${accent}22 !important;border-color:${accent}88 !important}
 #dp-root .dp-stat-num,#dp-root .dp-status,#dp-root .dp-pill svg,#dp-root .dp-video-sub,#dp-root .dp-credit strong{color:${accent} !important;text-shadow:none !important}
 #dp-root .dp-status{background:${accent}1f !important;border-color:${accent}66 !important}
 #dp-root .dp-status-dot{background:${accent} !important;box-shadow:0 0 8px ${accent} !important}
 #dp-root .dp-ver{background:${accent}1f !important;border-color:${accent}44 !important}
 #dp-root .dp-logo-img{box-shadow:0 4px 14px ${accent}55 !important}
 #dp-root .dp-h1,#dp-root .dp-subtitle,#dp-root .dp-icon-btn,#dp-root .dp-footer,#dp-root .dp-ghost-btn{color:#fff !important;text-shadow:none !important}
 .dp-card-btn{background:${card}!important;border-color:${accent}!important;color:${accent}!important;box-shadow:0 3px 12px #0006!important}
 .dp-card-btn svg{stroke:${accent}!important;filter:none!important}
 #dpDownloadNotice{background:${bg}!important;color:#fff!important;border-color:${accent}!important}
 `;}
 function applyTheme(t){let style=document.getElementById('alief-dola-theme');if(!style){style=document.createElement('style');style.id='alief-dola-theme';}const key=t.name+t.bg+t.card+t.accent;if(style.textContent===''||lastThemeKey!==key){style.textContent=themeCss(t);lastThemeKey=key;}const host=document.head||document.documentElement;if(style.parentNode!==host||host.lastElementChild!==style)host.appendChild(style);}
 async function syncTheme(){try{const t=await invoke('theme');if(!t||!THEMES[t.name])throw Error('tema tidak valid');applyTheme({...THEMES[t.name],...t});themeFailures=0;if(lastTheme!==t.name){lastTheme=t.name;invoke('diagnostic',{stage:'theme_applied_'+t.name}).catch(()=>{});}}catch(error){if(!lastTheme){applyTheme(THEMES.green);}if(themeFailures++===0)invoke('diagnostic',{stage:'theme_failed'}).catch(()=>{});}}
 syncTheme();setInterval(syncTheme,1500);document.addEventListener('visibilitychange',()=>{if(!document.hidden)syncTheme();});

 let recoverForAction=async media=>media;
 function showDolaNotice(message,error=false){let node=document.getElementById('dpDownloadNotice');if(!node){node=document.createElement('div');node.id='dpDownloadNotice';node.setAttribute('role','status');document.body.appendChild(node);}node.textContent=message;node.style.borderColor=error?'#fb7185':'#34d399';clearTimeout(node._timer);node._timer=setTimeout(()=>node.remove(),6500);}
 async function nativeAction(action,media){if(media?.url&&!canUseMedia(media)){showDolaNotice('Video ini bukan bagian dari chat aktif.',true);return false;}if(!media?.url||media.resolverSource!=='pc'){try{media=await within(recoverForAction(media),17000,'DOLA_RECOVERY');}catch(error){lastDolaError=error.message;showDolaNotice(error.message,true);return false;}}if(!media?.url){showDolaNotice('URL sumber belum ditemukan. '+(lastDolaError||'Buka Diagnostik Dola untuk melihat tahap pemeriksaan.')+'',true);return false;}if(!canUseMedia(media)){showDolaNotice('Video ini bukan bagian dari chat aktif.',true);return false;}try{await invoke(action,{url:media.url});if(action==='copy')showDolaNotice('Tautan video disalin.');return true;}catch(error){showDolaNotice(error.message||'Aksi video gagal. Periksa Diagnostik Dola.',true);return false;}}
 const backgroundListeners=[],contentListeners=[];
 const fire=(list,message)=>new Promise(resolve=>{
  let answered=false,async=false;const respond=value=>{if(answered)return;answered=true;clearTimeout(timer);resolve(value);};
  const timer=setTimeout(()=>respond({ok:false,error:'Aksi tidak menjawab [DOLA_CALLBACK]. Silakan coba lagi.'}),message.type==='TRIGGER_DOWNLOAD'?247000:15000);
  for(const listener of list){try{if(listener(message,{},respond)===true)async=true;}catch(error){respond({ok:false,error:error.message});}}
  if(!answered&&!async)respond({});
 });
 const storage={local:{get:(keys,cb)=>invoke('get').then(data=>{cb?.(data);return data;}).catch(()=>{cb?.({});return {};}),set:(value,cb)=>invoke('set',{value}).then(v=>{cb?.();return v;}).catch(e=>console.warn('[Alief Dola]',e.message))}};

 const common={storage,action:{setBadgeText(){},setBadgeBackgroundColor(){},setBadgeTextColor(){}},notifications:{create:opts=>invoke('notify',{message:opts.message})},downloads:{download:opts=>invoke('download',{url:opts.url,filename:opts.filename})}};
 const bg={...common,runtime:{onMessage:{addListener:fn=>backgroundListeners.push(fn)}},tabs:{query:(_query,cb)=>cb([{id:1}]),sendMessage:(_id,m)=>{if(m.type==='NEW_MEDIA_RESOLVED'&&m.media){m.media.resolverSource='pc';invoke('diagnostic',{stage:'pc_resolved',url:m.media.url}).catch(()=>{});}return fire(contentListeners,m);}}};
 const chrome={...common,runtime:{getURL:name=>browser.runtime.getURL(name),onMessage:{addListener:fn=>contentListeners.push(fn)},sendMessage:(m,cb)=>fire(backgroundListeners,m).then(r=>{cb?.(r);return r;})}};
 const fetchAdapter=async url=>{const result=await invoke('fetch',{url});return {ok:result.ok,status:result.status,json:async()=>{try{return typeof result.bodyText==='string'?JSON.parse(result.bodyText.replace(/^\uFEFF/,'')):result.data;}catch(error){invoke('diagnostic',{stage:'resolver_json_failed'}).catch(()=>{});throw error;}}};};
 // Run extension logic in the isolated preload, never expose Electron APIs to the page.
 ((chrome,fetch)=>{
// BEGIN PC RESOLVER (decoder and parameters retained; retry cache repaired)
// Unwatermark Dola | Background Service Worker
// Created by Alief Neutron

let capturedVideos = [];
let downloadedKeys = new Set();
let config = {
  autoDownload: false,
  subfolder: 'Dola_Pilot_Videos',
  notifications: true,
  totalDownloaded: 0
};

const QAAB_SALT_HEX = '4dd4c2e6b83162090e52b3c7a6733ba4'
  + '1cb2462b829ab58a196b39db57177524'
  + 'f49baf7f08e8d68d26a72e37c1a95a2f'
  + '1f05a51892aef2949732b62a38aadd58';

const processedApis = new Set();
const processedUrls = new Set();
const resolvedByApi=new Map();

// Initialize config from storage
chrome.storage.local.get(['dolaPilotConfig', 'earnifyxConfig'], (res) => {
  const saved = res.dolaPilotConfig || res.earnifyxConfig;
  if (saved) config = { ...config, ...saved };
  updateBadge();
});

function updateBadge() {
  const count = config.totalDownloaded || 0;
  chrome.action.setBadgeText({ text: count > 0 ? String(count) : '' });
  chrome.action.setBadgeBackgroundColor({ color: '#b3173d' });
  if (chrome.action.setBadgeTextColor) chrome.action.setBadgeTextColor({ color: '#ffffff' });
}

function sanitizeFilename(text) {
  return String(text || 'video')
    .normalize('NFKC')
    .replace(/[\u0000-\u001f]/g, ' ')          // control chars
    .replace(/[^\p{L}\p{N}]+/gu, '_')           // anything that is not a letter/number -> _
    .replace(/_+/g, '_')
    .replace(/^_+|_+$/g, '')
    .slice(0, 80)
    .replace(/_+$/g, '');
}

function generateFilename(media) {
  // Format: aliefneutron_<nama video>.mp4  (saved straight to Downloads;
  // duplicates are numbered automatically by the browser: "(1)", "(2)" ...)
  const slug = sanitizeFilename(media.prompt || '1080P_Master_Video') || 'video';
  return `aliefneutron_${slug}.mp4`;
}

function slugTitle(text) {
  if (!text) return '1080P Master Video';
  return text.length > 40 ? text.slice(0, 37) + '...' : text;
}

function hexToBytes(hex) {
  const bytes = new Uint8Array(hex.length / 2);
  for (let i = 0; i < bytes.length; i++) {
    bytes[i] = parseInt(hex.slice(i * 2, i * 2 + 2), 16);
  }
  return bytes;
}

function concatBytes(first, second) {
  const bytes = new Uint8Array(first.length + second.length);
  bytes.set(first, 0);
  bytes.set(second, first.length);
  return bytes;
}

function padBase64(text) {
  const pad = (4 - (text.length % 4)) % 4;
  return text + '='.repeat(pad);
}

function base64DecodeLoose(text) {
  const input = String(text || '').trim();
  const variants = [
    input,
    input.replace(/[$@#]/g, char => ({ '$': '_', '@': '/', '#': '.' }[char])),
    input.replace(/[$@#]/g, char => ({ '$': '+', '@': '/', '#': '=' }[char])),
  ];
  for (const candidate of variants) {
    try {
      const normalized = padBase64(candidate).replace(/-/g, '+').replace(/_/g, '/');
      const binary = atob(normalized);
      const bytes = new Uint8Array(binary.length);
      for (let i = 0; i < binary.length; i++) {
        bytes[i] = binary.charCodeAt(i);
      }
      return bytes;
    } catch {}
  }
  return null;
}

function asciiUrlFromBytes(bytes) {
  if (!bytes || !bytes.length) return '';
  for (const byte of bytes) {
    if (byte !== 9 && byte !== 10 && byte !== 13 && (byte < 32 || byte > 126)) return '';
  }
  return new TextDecoder().decode(bytes);
}

function stripPkcs7(bytes) {
  if (!bytes || !bytes.length) return new Uint8Array();
  const pad = bytes[bytes.length - 1];
  if (pad < 1 || pad > 16 || pad > bytes.length) return bytes;
  for (let i = bytes.length - pad; i < bytes.length; i++) {
    if (bytes[i] !== pad) return bytes;
  }
  return bytes.slice(0, bytes.length - pad);
}

async function decryptAesCbcUrl(payload, keyBytes, ivBytes) {
  if (!payload.length || payload.length % 16 !== 0) return '';
  try {
    const key = await crypto.subtle.importKey('raw', keyBytes, 'AES-CBC', false, ['decrypt']);
    const plain = new Uint8Array(await crypto.subtle.decrypt({ name: 'AES-CBC', iv: ivBytes }, key, payload));
    const direct = asciiUrlFromBytes(plain);
    if (/^https?:\/\//i.test(direct)) return direct;
    const stripped = stripPkcs7(plain);
    const url = asciiUrlFromBytes(stripped);
    return /^https?:\/\//i.test(url) ? url : '';
  } catch {
    return '';
  }
}

async function decodeQaabToken(token, keySeed) {
  const data = base64DecodeLoose(token);
  const seed = base64DecodeLoose(keySeed);
  if (!data || !seed) return '';

  const digest1 = await crypto.subtle.digest('SHA-512', seed.slice(0, 32));
  const salt = hexToBytes(QAAB_SALT_HEX);
  const digest2Input = concatBytes(new Uint8Array(digest1), salt);
  const digest2 = new Uint8Array(await crypto.subtle.digest('SHA-512', digest2Input));
  const key = digest2.slice(0, 16);
  const iv = digest2.slice(16, 32);
  const attempts = [];

  if (data.length >= 4 && data[0] === 0xa8 && data[1] === 0x00 && data[2] === 0x01 && data[3] === 0x00) {
    attempts.push({ payload: data.slice(4), key, iv });
    attempts.push({ payload: data.slice(4), key: iv, iv: key });
    if (data.length > 36) {
      attempts.push({ payload: data.slice(36), key, iv: data.slice(20, 36) });
      attempts.push({ payload: data.slice(36), key, iv });
    }
  } else {
    attempts.push({ payload: data, key, iv });
  }

  for (const attempt of attempts) {
    const url = await decryptAesCbcUrl(attempt.payload, attempt.key, attempt.iv);
    if (url) return url;
  }
  return '';
}

async function decodeMainUrl(token, keySeed = '') {
  if (!token) return '';
  if (/^https?:\/\//i.test(token.trim())) return token.trim();
  const bytes = base64DecodeLoose(token);
  if (bytes) {
    const text = asciiUrlFromBytes(bytes);
    if (/^https?:\/\//i.test(text)) return text;
  }
  if (token.startsWith('qAAB') && keySeed) {
    return await decodeQaabToken(token, keySeed);
  }
  return '';
}

function findKeySeedDeep(value, depth = 0) {
  if (depth > 10 || value == null) return '';
  if (typeof value === 'string') {
    let match = value.match(/(?:^|[?&])key_seed=([^&"'<>\\\s]+)/i);
    if (match) return decodeURIComponent(match[1]);
    match = value.match(/["']key_seed["']\s*:\s*["']([^"']+)/i);
    return match ? decodeURIComponent(match[1]) : '';
  }
  if (typeof value !== 'object') return '';
  if (typeof value.key_seed === 'string' && value.key_seed.trim()) return value.key_seed.trim();
  for (const item of Object.values(value)) {
    const hit = findKeySeedDeep(item, depth + 1);
    if (hit) return hit;
  }
  return '';
}

function pickBestToken(data) {
  const list = data?.video_list ? Object.values(data.video_list) : [data];
  let best = '';
  let maxScore = 0;
  for (const item of list) {
    const tok = item?.main_url || item?.play_url;
    const score = Number(item?.bitrate || 0) + Number(item?.width || 0) * Number(item?.height || 0);
    if (tok && score >= maxScore) {
      maxScore = score;
      best = tok;
    }
  }
  return best;
}

function extractTOSKey(url) {
  if (!url) return '';
  try {
    const u = new URL(url);
    const path = u.pathname;
    const tosMatch = path.match(/tos-[a-zA-Z0-9_-]+\/([a-zA-Z0-9_-]+)/i);
    if (tosMatch && tosMatch[1]) {
      return tosMatch[1].split('~')[0].split('.')[0];
    }
    const parts = path.split('/').filter(Boolean);
    const last = parts[parts.length - 1] || '';
    return last.split('~')[0].split('.')[0];
  } catch {
    const clean = String(url).split('?')[0];
    const match = clean.match(/tos-[a-zA-Z0-9_-]+\/([a-zA-Z0-9_-]+)/i);
    return match ? match[1].split('~')[0].split('.')[0] : '';
  }
}

const activeResolutions=new Map();
function resolveFallbackApi(fallbackUrl,keySeed='',meta={},force=false){if(activeResolutions.has(fallbackUrl))return activeResolutions.get(fallbackUrl);const promise=resolveFallbackOnce(fallbackUrl,keySeed,meta,force);activeResolutions.set(fallbackUrl,promise);promise.finally(()=>activeResolutions.delete(fallbackUrl));return promise;}
async function resolveFallbackOnce(fallbackUrl, keySeed = '', meta = {}, force=false) {
  if(!fallbackUrl)return null;
  if(force)resolvedByApi.delete(fallbackUrl);
  if(resolvedByApi.has(fallbackUrl)){const cached=resolvedByApi.get(fallbackUrl);if(meta.chatId)cached.chatId=meta.chatId;if(meta.poster)cached.poster=meta.poster;if(meta.messageId)cached.messageId=meta.messageId;return cached;}
  if(processedApis.has(fallbackUrl))return null;
  processedApis.add(fallbackUrl);

  try {
    const u = new URL(fallbackUrl);
    u.searchParams.set('channel', 'no');
    u.searchParams.set('codec_type', '8');
    u.searchParams.set('logo_type', 'unwatermarked');

    const resp = await fetch(u.toString());
    if (!resp.ok) return null;

    const payload = await resp.json();
    invoke('diagnostic',{stage:'payload_type_'+typeof payload}).catch(()=>{});
    const candidates=[];let visited=0,mask=0;
    const rawSeedMatch=String(fallbackUrl).match(/[?&]key_seed=([^&#]*)/i);let rawSeed='';try{rawSeed=rawSeedMatch?decodeURIComponent(rawSeedMatch[1]):'';}catch{}
    const querySeed=rawSeed||keySeed||'';
    function inspect(node,depth=0,seeds=[]){
      if(depth>12||visited++>3000||node==null)return;
      if(typeof node==='string'){if(node.length<=2*1024*1024&&/^[\s]*[\[{]/.test(node)){try{inspect(JSON.parse(node),depth+1,seeds);}catch{}}return;}
      if(typeof node!=='object')return;
      if(node.data!==undefined||node.Data!==undefined)mask|=1;if(node.video_info||node.VideoInfo)mask|=2;if(node.video_list||node.VideoList)mask|=4;if(typeof node.code==='number'&&node.code!==0)mask|=8;
      const seed=node.key_seed||node.keySeed||node.KeySeed;const local=[...(typeof seed==='string'?[seed]:[]),...seeds];
      if(local.length)mask|=16;
      for(const key of ['main_url','play_url','MainPlayUrl','MainUrl','PlayUrl']){const token=node[key];if(typeof token==='string'&&token)candidates.push({token,seeds:local,width:Number(node.width||node.Width)||0,height:Number(node.height||node.Height)||0,score:(Number(node.bitrate||node.Bitrate)||0)+(Number(node.width||node.Width)||0)*(Number(node.height||node.Height)||0),node});}
      for(const child of Object.values(node))if(child&&typeof child==='object'||typeof child==='string')inspect(child,depth+1,local);
    }
    inspect(payload,0,[querySeed,findKeySeedDeep(payload)].filter(Boolean));
    if(!candidates.length){invoke('diagnostic',{stage:'resolver_no_token',count:mask}).catch(()=>{});return null;}
    candidates.sort((a,b)=>b.score-a.score);invoke('diagnostic',{stage:'resolver_tokens',count:candidates.length}).catch(()=>{});
    let rawUrl='',videoData=null,attempts=0;
    for(const candidate of candidates.slice(0,12)){
      const seeds=[...new Set([...candidate.seeds,querySeed,findKeySeedDeep(payload),''])].slice(0,5);
      for(const seed of seeds){attempts++;try{let decoded='';try{decoded=await within(decodeMainUrl(candidate.token,seed),2500,'DOLA_DECODE');}catch{}if(!/^https?:\/\//i.test(decoded)){invoke('diagnostic',{stage:candidate.token.startsWith('qAAB')?'token_qaab':'token_other',count:candidate.token.length}).catch(()=>{});decoded=await invoke('decode',{token:candidate.token,seed});}if(/^https?:\/\//i.test(decoded)){rawUrl=decoded;videoData=candidate.node;break;}}catch{}}
      if(rawUrl)break;
    }
    if(!rawUrl){invoke('diagnostic',{stage:'resolver_decode_failed',count:attempts}).catch(()=>{});return null;}
    if (rawUrl && /^https?:\/\//i.test(rawUrl)) {
      processedUrls.add(rawUrl);
      console.log('💎 [Unwatermark Dola BG] Found 1080P Unwatermarked Master Video:', rawUrl);

      const media = {
        vid: videoData?.vid || videoData?.video_id || meta.vid || fallbackUrl,
        url: rawUrl,
        poster: videoData?.poster_url || videoData?.poster || meta.poster || '',
        prompt: meta.prompt || videoData?.prompt || 'Dola 1080P Unwatermarked Video',
        chatId: meta.chatId || meta.chat_id || meta.conversation_id || '',
        messageId: meta.messageId || '',
        width: videoData?.width || 1080,
        height: videoData?.height || 1920,
        duration: videoData?.duration || 0,
        fallbackUrl,
        timestamp: Date.now()
      };

      const mediaKey = extractTOSKey(media.poster) || extractTOSKey(media.url) || media.vid;
      const existingIndex = capturedVideos.findIndex(v => {
        const vk = extractTOSKey(v.poster) || extractTOSKey(v.url) || v.vid;
        return (mediaKey && vk && mediaKey === vk) || (media.vid && v.vid === media.vid) || v.url === media.url;
      });

      if (existingIndex >= 0) {
        capturedVideos[existingIndex] = { ...capturedVideos[existingIndex], ...media };
      } else {
        capturedVideos.push(media);
        if (capturedVideos.length > 100) capturedVideos.shift();
      }

      // Broadcast to tabs
      chrome.tabs.query({}, (tabs) => {
        tabs.forEach(tab => {
          if (tab.id) {
            chrome.tabs.sendMessage(tab.id, { type: 'NEW_MEDIA_RESOLVED', media }).catch(() => {});
          }
        });
      });

      if (config.autoDownload && canUseMedia(media)) {
        triggerDownload(media, true);
      }

      resolvedByApi.set(fallbackUrl,media);
      return media;
    }
  } catch (e) {
    console.warn('[Alief Dola] Resolver gagal; percobaan berikutnya tetap diizinkan.');
  } finally {processedApis.delete(fallbackUrl);}
  return null;
}

async function triggerDownload(media, isAuto = false) {
  if (!media || !media.url || !canUseMedia(media)) return { ok: false, error: 'Video bukan bagian dari chat aktif.' };

  const key = media.vid || media.url;
  if (isAuto && downloadedKeys.has(key)) return { ok: true, skipped: true };
  downloadedKeys.add(key);

  const filename = generateFilename(media);

  try {
    const downloadId = await chrome.downloads.download({
      url: media.url,
      filename,
      saveAs: false,
      conflictAction: 'uniquify'
    });

    config.totalDownloaded = (config.totalDownloaded || 0) + 1;
    chrome.storage.local.set({ dolaPilotConfig: config });
    updateBadge();

    if (config.notifications) {
      try {
        chrome.notifications.create({
          type: 'basic',
          iconUrl: 'icon128.png',
          title: 'Unwatermark Dola · Video tersimpan',
          message: `${slugTitle(media.prompt)}\nby Alief Neutron`,
          priority: 1
        });
      } catch (e) {}
    }

    return { ok: true, downloadId, filename };
  } catch (err) {
    downloadedKeys.delete(key);
    console.error('Download error:', err);
    return { ok: false, error: err.message };
  }
}

// Handle runtime messages
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'FETCH_AND_RESOLVE_FALLBACK') {
    resolveFallbackApi(message.fallbackUrl, message.keySeed, message.meta,!!message.force).then(res => {
      sendResponse({ ok: !!res, media: res });
    });
    return true;
  }

  if (message.type === 'NEW_MEDIA_DETECTED') {
    const media = message.media;
    if (media && media.url) {
      const existingIndex = capturedVideos.findIndex(v => 
        (media.vid && v.vid === media.vid) || v.url === media.url
      );
      if (existingIndex >= 0) {
        capturedVideos[existingIndex] = { ...capturedVideos[existingIndex], ...media };
      } else {
        capturedVideos.push(media);
        if (capturedVideos.length > 100) capturedVideos.shift();
        if (config.autoDownload && canUseMedia(media)) {
          triggerDownload(media, true);
        }
      }
    }
    sendResponse({ ok: true });
  }

  if (message.type === 'TRIGGER_DOWNLOAD') {
    triggerDownload(message.media, false).then(sendResponse);
    return true;
  }

  if (message.type === 'GET_CAPTURED_VIDEOS') {
    // Return videos in chronological 1st -> Nth order (Scene 1 on top, Scene 2 second, etc.)
    const sorted = [...capturedVideos].sort((a, b) => {
      const aMatch = String(a.prompt || '').match(/Scene[_\s]*(\d+)/i);
      const bMatch = String(b.prompt || '').match(/Scene[_\s]*(\d+)/i);
      if (aMatch && bMatch) {
        return parseInt(aMatch[1], 10) - parseInt(bMatch[1], 10);
      }
      return (a.timestamp || 0) - (b.timestamp || 0);
    });
    sendResponse({ videos: sorted, config });
  }

  if (message.type === 'CLEAR_VIDEOS') {
    capturedVideos = [];
    sendResponse({ ok: true });
  }

  if (message.type === 'UPDATE_CONFIG') {
    config = { ...config, ...message.config };
    chrome.storage.local.set({ dolaPilotConfig: config });
    updateBadge();
    sendResponse({ ok: true, config });
  }
});

// END PC RESOLVER
 })(bg,fetchAdapter);
 const style=()=>{if(document.getElementById('alief-dola-style'))return;const node=document.createElement('style');node.id='alief-dola-style';node.textContent="/* Unwatermark Dola | Glassmorphic in-page UI (burgundy)\n   Default: collapsed pill. Click the pill -> full panel.\n   Created by Alief Neutron */\n\n#dp-root {\n  --dp-glass: rgba(150, 30, 66, 0.46);\n  --dp-glass-hi: rgba(255, 255, 255, 0.16);\n  --dp-border: rgba(255, 205, 214, 0.5);\n  --dp-border-soft: rgba(255, 205, 214, 0.26);\n  --dp-text: #ffffff;\n  --dp-muted: rgba(255, 236, 240, 0.92);\n  --dp-ok: #34d399;\n  --dp-grad: linear-gradient(135deg, #a31638 0%, #cf1f4a 55%, #fb3b64 100%);\n  --dp-blur: blur(14px) saturate(140%);\n  color-scheme: dark;\n  -webkit-text-size-adjust: 100%;\n  text-size-adjust: 100%;\n\n  position: fixed;\n  right: 20px;\n  bottom: 92px;\n  z-index: 2147483640;\n  width: max-content;\n  color: var(--dp-text);\n  font-family: \"Segoe UI Variable\", \"Segoe UI\", Inter, system-ui, -apple-system, Roboto, sans-serif;\n  font-size: 12px;\n  line-height: 1.3;\n  user-select: none;\n  pointer-events: auto;\n}\n\n#dp-root *, #dp-root *::before, #dp-root *::after {\n  box-sizing: border-box;\n  font-family: inherit;\n  margin: 0;\n  padding: 0;\n}\n#dp-root button { font: inherit; color: inherit; }\n\n/* ---------- collapsed pill (default) ---------- */\n#dp-root .dp-pill {\n  display: inline-flex;\n  align-items: center; gap: 6px;\n  padding: 5px 10px;\n  border-radius: 12px;\n  color: #fff;\n  font-weight: 700;\n  font-size: 11px;\n  cursor: pointer;\n  touch-action: none;\n  background: linear-gradient(180deg, rgba(255,255,255,0.16), rgba(255,255,255,0.02)), rgba(120, 18, 48, 0.88);\n  border: 1px solid var(--dp-border);\n  -webkit-backdrop-filter: var(--dp-blur);\n  backdrop-filter: var(--dp-blur);\n  box-shadow: 0 12px 36px rgba(25,2,9,.6), 0 1px 0 rgba(255,255,255,.35) inset;\n  transition: transform .2s, box-shadow .2s;\n}\n#dp-root .dp-pill:hover { transform: translateY(-2px); box-shadow: 0 16px 42px rgba(25,2,9,.7), 0 0 22px rgba(225,29,72,.55); }\n#dp-root.dp-dragging .dp-pill { cursor: grabbing; transform: none; }\n#dp-root .dp-pill svg { color: #fda4af; }\n#dp-root .dp-pill-count { background: var(--dp-grad); padding: 0 7px; border-radius: 6px; font-size: 10.5px; font-variant-numeric: tabular-nums; }\n#dp-root.dp-open .dp-pill { box-shadow: 0 12px 36px rgba(25,2,9,.6), 0 0 0 1px rgba(251,113,133,.55), 0 1px 0 rgba(255,255,255,.35) inset; }\n\n/* ---------- expanded panel ---------- */\n#dp-root .dp-panel {\n  display: none;\n  position: absolute;\n  right: 0;\n  bottom: calc(100% + 10px);\n  width: 320px;\n  max-width: calc(100vw - 16px);\n  overflow: hidden;\n  border-radius: 18px;\n  border: 1px solid var(--dp-border);\n  background:\n    radial-gradient(120% 80% at 0% 0%, #b3173f 0%, transparent 62%),\n    radial-gradient(110% 90% at 100% 100%, #8c1030 0%, transparent 58%),\n    linear-gradient(160deg, #5a0f26, #3a0818);\n  box-shadow: 0 24px 70px rgba(25, 2, 9, 0.7), 0 1px 0 rgba(255,255,255,0.3) inset;\n}\n#dp-root.dp-open .dp-panel { display: block; animation: dpRise .28s cubic-bezier(.16,1,.3,1); }\n#dp-root.dp-align-left .dp-panel { right: auto; left: 0; }\n#dp-root.dp-open-down .dp-panel { bottom: auto; top: calc(100% + 10px); }\n\n#dp-root .dp-orb { position: absolute; border-radius: 50%; filter: blur(38px); opacity: .7; pointer-events: none; }\n#dp-root .dp-orb-a { width: 210px; height: 210px; background: #be123c; top: -60px; left: -50px; animation: dpDrift 14s ease-in-out infinite alternate; }\n#dp-root .dp-orb-b { width: 230px; height: 230px; background: #e11d48; bottom: -80px; right: -70px; opacity: .45; animation: dpDrift 17s ease-in-out infinite alternate-reverse; }\n#dp-root .dp-orb-c { width: 150px; height: 150px; background: #f59e0b; top: 42%; right: -50px; opacity: .22; animation: dpDrift 12s ease-in-out infinite alternate; }\n\n#dp-root .dp-app { position: relative; z-index: 1; padding: 11px; display: flex; flex-direction: column; gap: 9px; }\n\n#dp-root .dp-glass {\n  background: linear-gradient(160deg, rgba(255,255,255,0.07), rgba(255,255,255,0) 50%), var(--dp-glass);\n  border: 1px solid var(--dp-border);\n  border-radius: 14px;\n  -webkit-backdrop-filter: var(--dp-blur);\n  backdrop-filter: var(--dp-blur);\n  box-shadow: 0 10px 34px rgba(20, 1, 7, 0.5), 0 1px 0 rgba(255,255,255,0.32) inset;\n}\n\n/* header */\n#dp-root .dp-header { display: flex; align-items: center; justify-content: space-between; padding: 8px 10px; }\n#dp-root .dp-logo-group { display: flex; align-items: center; gap: 9px; }\n#dp-root .dp-logo-img { width: 30px; height: 30px; border-radius: 9px; box-shadow: 0 6px 18px rgba(225,29,72,.55); }\n#dp-root .dp-h1 { font-size: 14px; font-weight: 800; letter-spacing: .2px; color: #ffffff; text-shadow: 0 1px 8px rgba(0,0,0,.45); }\n#dp-root .dp-subtitle { font-size: 10px; color: #ffe9ee; opacity: .95; margin-top: 1px; }\n#dp-root .dp-status { display: flex; align-items: center; gap: 6px; padding: 3px 9px; border-radius: 8px; background: rgba(52,211,153,.12); border: 1px solid rgba(52,211,153,.4); font-size: 10px; font-weight: 700; color: #6ee7b7; }\n#dp-root .dp-status-dot { width: 7px; height: 7px; border-radius: 50%; background: var(--dp-ok); box-shadow: 0 0 10px var(--dp-ok); animation: dpBlink 2.4s ease-in-out infinite; }\n\n/* stats */\n#dp-root .dp-stats { display: grid; grid-template-columns: 1fr 1fr; gap: 9px; }\n#dp-root .dp-stat { display: flex; flex-direction: column; align-items: center; padding: 7px 6px; }\n#dp-root .dp-stat-num { font-size: 20px; font-weight: 800; line-height: 1.25; font-variant-numeric: tabular-nums; color: #ffe1e7; text-shadow: 0 0 14px rgba(255,93,125,.7), 0 1px 4px rgba(0,0,0,.4); }\n#dp-root .dp-stat-label { font-size: 9.5px; color: var(--dp-muted); }\n\n/* controls */\n#dp-root .dp-controls { padding: 2px 11px; }\n#dp-root .dp-control-row { display: flex; align-items: center; justify-content: space-between; gap: 10px; padding: 7px 0; }\n#dp-root .dp-control-row + .dp-control-row { border-top: 1px solid var(--dp-border-soft); }\n#dp-root .dp-control-text { display: flex; flex-direction: column; gap: 2px; }\n#dp-root .dp-control-text strong { font-size: 11.5px; font-weight: 700; }\n#dp-root .dp-control-text small { font-size: 9.5px; color: var(--dp-muted); }\n\n#dp-root .dp-switch { position: relative; width: 34px; height: 18px; flex-shrink: 0; display: inline-block; }\n#dp-root .dp-switch input { opacity: 0; width: 0; height: 0; position: absolute; }\n#dp-root .dp-slider { position: absolute; inset: 0; cursor: pointer; border-radius: 999px; background: rgba(255,255,255,.30); border: 1px solid var(--dp-border-soft); transition: background .25s, box-shadow .25s; }\n#dp-root .dp-slider::before { content: \"\"; position: absolute; top: 2px; left: 2px; width: 12px; height: 12px; border-radius: 50%; background-color: #ffffff; box-shadow: 0 2px 6px rgba(0,0,0,.4); transition: transform .25s cubic-bezier(.3,1.4,.5,1); }\n#dp-root .dp-switch input:checked + .dp-slider { background: var(--dp-grad); box-shadow: 0 0 16px rgba(225,29,72,.65); }\n#dp-root .dp-switch input:checked + .dp-slider::before { transform: translateX(16px); }\n\n/* buttons */\n#dp-root .dp-primary-btn, #dp-root .dp-ghost-btn, #dp-root .dp-icon-btn { cursor: pointer; color: #fff; transition: transform .18s, box-shadow .2s, background .2s, opacity .2s; }\n#dp-root .dp-primary-btn { border: 1px solid rgba(255,255,255,.3); background: var(--dp-grad); border-radius: 8px; padding: 5px 12px; font-size: 11px; font-weight: 700; box-shadow: 0 6px 20px rgba(190,18,60,.5), 0 1px 0 rgba(255,255,255,.4) inset; }\n#dp-root .dp-primary-btn.dp-small { padding: 3px 10px; font-size: 10.5px; border-radius: 7px; }\n#dp-root .dp-primary-btn:hover:not(:disabled) { transform: translateY(-1px); box-shadow: 0 10px 26px rgba(225,29,72,.65), 0 1px 0 rgba(255,255,255,.4) inset; }\n#dp-root .dp-primary-btn:active:not(:disabled) { transform: scale(.97); }\n#dp-root .dp-primary-btn:disabled { opacity: .6; cursor: wait; }\n#dp-root .dp-primary-btn.dp-ok { background: linear-gradient(135deg, #10b981, #34d399); }\n#dp-root .dp-primary-btn.dp-err { background: linear-gradient(135deg, #e11d48, #fb7185); }\n#dp-root .dp-ghost-btn { background: var(--dp-glass-hi); border: 1px solid var(--dp-border); border-radius: 8px; padding: 4px 11px; font-size: 10.5px; font-weight: 600; }\n#dp-root .dp-ghost-btn:hover { background: rgba(255,255,255,.22); }\n#dp-root .dp-icon-btn { width: 24px; height: 24px; display: inline-flex; align-items: center; justify-content: center; border-radius: 7px; background: var(--dp-glass-hi); border: 1px solid var(--dp-border-soft); color: #ffe4e6; }\n#dp-root .dp-icon-btn:hover { background: rgba(255,255,255,.22); border-color: var(--dp-border); color: #fff; }\n#dp-root .dp-icon-btn.dp-ok { background: rgba(52,211,153,.3); border-color: rgba(52,211,153,.7); }\n\n/* icon-only download button */\n#dp-root .dp-save-ico { width: 34px; height: 24px; padding: 0; display: inline-flex; align-items: center; justify-content: center; }\n#dp-root .dp-save-ico svg { display: block; }\n#dp-root .dp-save-ico.dp-busy svg { animation: dpBob .7s ease-in-out infinite; }\n#dp-root .dp-save-ico:disabled { cursor: default; }\n\n/* list */\n#dp-root .dp-section-title { display: flex; align-items: center; justify-content: space-between; padding: 0 3px; font-size: 10px; font-weight: 800; letter-spacing: 1.1px; text-transform: uppercase; color: var(--dp-muted); }\n#dp-root .dp-list { display: flex; flex-direction: column; gap: 6px; max-height: 188px; overflow-y: auto; padding: 2px 3px 2px 0; }\n#dp-root .dp-list::-webkit-scrollbar { width: 6px; }\n#dp-root .dp-list::-webkit-scrollbar-thumb { background: rgba(255,255,255,.22); border-radius: 6px; }\n\n#dp-root .dp-empty-state { display: flex; flex-direction: column; align-items: center; text-align: center; gap: 8px; padding: 18px 14px; color: var(--dp-muted); border: 1px dashed var(--dp-border); border-radius: 14px; background: rgba(255,255,255,.04); }\n#dp-root .dp-empty-state p { font-size: 11px; line-height: 1.5; }\n\n#dp-root .dp-video-item { display: flex; align-items: center; justify-content: space-between; gap: 8px; padding: 5px 7px; border-radius: 11px; background: rgba(150,30,66,.55); border: 1px solid var(--dp-border-soft); transition: background .2s, border-color .2s, transform .2s; }\n#dp-root .dp-video-item:hover { background: rgba(180,36,78,.7); border-color: rgba(255,160,178,.8); transform: translateY(-1px); }\n#dp-root .dp-video-left { display: flex; align-items: center; gap: 8px; min-width: 0; flex: 1; }\n#dp-root .dp-thumb { width: 34px; height: 34px; border-radius: 8px; flex-shrink: 0; overflow: hidden; display: flex; align-items: center; justify-content: center; background: linear-gradient(135deg, rgba(190,18,60,.55), rgba(251,191,36,.28)); border: 1px solid var(--dp-border); color: #fff; }\n#dp-root .dp-thumb img { width: 100%; height: 100%; object-fit: cover; display: block; }\n#dp-root .dp-video-info { min-width: 0; display: flex; flex-direction: column; gap: 3px; }\n#dp-root .dp-video-title { display: flex; align-items: flex-start; gap: 6px; font-weight: 600; font-size: 11px; min-width: 0; line-height: 1.25; }\n#dp-root .dp-name { display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; word-break: break-word; }\n#dp-root .dp-num { flex-shrink: 0; margin-top: 1px; font-size: 9px; font-weight: 800; padding: 0 5px; border-radius: 5px; color: #fda4af; background: rgba(225,29,72,.25); border: 1px solid rgba(251,113,133,.6); }\n#dp-root .dp-video-sub { font-size: 9.5px; color: #ffe08a; font-weight: 600; }\n#dp-root .dp-video-actions { display: flex; align-items: center; gap: 5px; flex-shrink: 0; }\n\n/* footer credit */\n#dp-root .dp-credit { display: flex; align-items: center; justify-content: center; gap: 6px; font-size: 10px; color: var(--dp-muted); }\n#dp-root .dp-credit strong { font-weight: 800; color: #ffd1d8; }\n#dp-root .dp-ver { margin-left: 4px; padding: 0 6px; border-radius: 6px; font-size: 9px; background: rgba(255,255,255,.09); border: 1px solid var(--dp-border-soft); }\n\n/* ---------- on-card button ---------- */\n.dp-card-btn {\n  position: absolute !important;\n  top: 8px; right: 8px;\n  z-index: 99999;\n  display: inline-flex; align-items: center; gap: 5px;\n  padding: 4px 9px;\n  font-family: \"Segoe UI Variable\", \"Segoe UI\", Inter, system-ui, -apple-system, Roboto, sans-serif;\n  font-size: 10.5px; font-weight: 700; line-height: 1.2;\n  color: #fff !important;\n  background:\n    linear-gradient(180deg, rgba(255,255,255,0.12), rgba(255,255,255,0)),\n    rgba(110, 12, 36, 0.92) !important;\n  border: 1px solid rgba(255,255,255,0.32) !important;\n  border-radius: 8px;\n  cursor: pointer;\n  -webkit-backdrop-filter: blur(6px) saturate(130%);\n  backdrop-filter: blur(6px) saturate(130%);\n  box-shadow: 0 8px 24px rgba(25, 2, 9, 0.5), 0 1px 0 rgba(255,255,255,.45) inset;\n  transition: transform .2s cubic-bezier(.4,0,.2,1), box-shadow .2s, background .2s;\n}\n.dp-card-btn:hover:not(:disabled) {\n  transform: translateY(-1px);\n  box-shadow: 0 12px 30px rgba(225,29,72,.6), 0 1px 0 rgba(255,255,255,.5) inset;\n  background:\n    linear-gradient(180deg, rgba(255,255,255,0.16), rgba(255,255,255,0)),\n    rgba(170, 20, 58, 0.96) !important;\n}\n.dp-card-btn:active:not(:disabled) { transform: scale(.97); }\n.dp-card-btn svg { width: 12px; height: 12px; stroke: #fff; filter: drop-shadow(0 0 4px rgba(255,255,255,.5)); }\n.dp-card-btn.dp-loading { opacity: .85; cursor: wait; }\n.dp-card-btn.dp-success { background: linear-gradient(135deg, rgba(16,185,129,.85), rgba(52,211,153,.75)) !important; }\n.dp-card-btn.dp-error { background: linear-gradient(135deg, rgba(225,29,72,.85), rgba(251,113,133,.75)) !important; }\n\n/* ---------- animations ---------- */\n@keyframes dpRise { from { opacity: 0; transform: translateY(8px) scale(.98); } to { opacity: 1; transform: translateY(0) scale(1); } }\n@keyframes dpDrift { from { transform: translate(0,0) scale(1); } to { transform: translate(34px, 26px) scale(1.12); } }\n@keyframes dpBob { 50% { transform: translateY(2px); } }\n@keyframes dpBlink { 50% { opacity: .45; } }\n\n@media (prefers-reduced-motion: reduce) {\n  #dp-root *, .dp-card-btn { animation: none !important; transition: none !important; }\n}\n\n/* ---------- phones / touch ---------- */\n@media (max-width: 600px), (pointer: coarse) {\n  #dp-root { font-size: 14px; right: 14px; bottom: 96px; }\n  #dp-root .dp-pill { padding: 8px 14px; font-size: 14px; gap: 8px; border-radius: 16px; }\n  #dp-root .dp-pill svg { width: 18px; height: 18px; }\n  #dp-root .dp-pill-count { font-size: 13.5px; padding: 1px 9px; }\n  #dp-root .dp-panel { width: min(360px, calc(100vw - 24px)); border-radius: 22px; }\n  #dp-root .dp-app { padding: 13px; gap: 11px; }\n  #dp-root .dp-logo-img { width: 38px; height: 38px; }\n  #dp-root .dp-h1 { font-size: 17px; }\n  #dp-root .dp-subtitle { font-size: 12px; }\n  #dp-root .dp-status { font-size: 12.5px; padding: 5px 11px; }\n  #dp-root .dp-stat { padding: 10px 6px; }\n  #dp-root .dp-stat-num { font-size: 26px; }\n  #dp-root .dp-stat-label { font-size: 12px; }\n  #dp-root .dp-controls { padding: 3px 13px; }\n  #dp-root .dp-control-row { padding: 11px 0; }\n  #dp-root .dp-control-text strong { font-size: 14.5px; }\n  #dp-root .dp-control-text small { font-size: 12px; }\n  #dp-root .dp-switch { width: 46px; height: 26px; }\n  #dp-root .dp-slider::before { width: 18px; height: 18px; top: 3px; left: 3px; }\n  #dp-root .dp-switch input:checked + .dp-slider::before { transform: translateX(20px); }\n  #dp-root .dp-ghost-btn { font-size: 13px; padding: 8px 14px; }\n  #dp-root .dp-section-title { font-size: 12px; }\n  #dp-root .dp-primary-btn.dp-small { font-size: 13px; padding: 7px 14px; }\n  #dp-root .dp-icon-btn { width: 34px; height: 34px; }\n  #dp-root .dp-save-ico { width: 44px; height: 34px; }\n  #dp-root .dp-save-ico svg { width: 18px; height: 18px; }\n  #dp-root .dp-list { max-height: 34vh; }\n  #dp-root .dp-thumb { width: 44px; height: 44px; }\n  #dp-root .dp-video-title { font-size: 13px; }\n  #dp-root .dp-num { font-size: 11px; }\n  #dp-root .dp-video-sub { font-size: 11.5px; }\n  #dp-root .dp-empty-state p { font-size: 13.5px; }\n  #dp-root .dp-credit { font-size: 12px; }\n  #dp-root .dp-ver { font-size: 11px; }\n}\n\n/* Compact Android workspace viewport, including short landscape screens. */\n@media (max-width: 600px), (pointer: coarse) {\n #dp-root {font-size:11px;right:8px;bottom:12px;}\n #dp-root .dp-pill {font-size:11px;padding:6px 9px;gap:5px;border-radius:11px;}\n #dp-root .dp-pill svg {width:14px;height:14px;}\n #dp-root .dp-pill-count {font-size:10px;padding:0 6px;}\n #dp-root .dp-panel {position:fixed!important;top:8px!important;right:8px!important;left:auto!important;bottom:auto!important;width:min(280px,calc(100vw - 16px));max-height:calc(100vh - 56px);max-height:calc(100dvh - 56px);overflow:auto;overscroll-behavior:contain;border-radius:14px;}\n #dp-root .dp-app {padding:8px;gap:6px;}\n #dp-root .dp-header {padding:8px;}\n #dp-root .dp-logo-img {width:26px;height:26px;}\n #dp-root .dp-h1 {font-size:13px;}\n #dp-root .dp-subtitle {font-size:9px;}\n #dp-root .dp-status {font-size:10px;padding:3px 7px;}\n #dp-root .dp-stat {padding:5px;}\n #dp-root .dp-stat-num {font-size:19px;}\n #dp-root .dp-stat-label {font-size:9px;}\n #dp-root .dp-controls {padding:0 8px;}\n #dp-root .dp-control-row {padding:6px 0;}\n #dp-root .dp-control-text strong {font-size:11px;}\n #dp-root .dp-control-text small {font-size:9px;}\n #dp-root .dp-switch {width:34px;height:20px;}\n #dp-root .dp-slider::before {width:14px;height:14px;top:2px;left:2px;}\n #dp-root .dp-switch input:checked + .dp-slider::before {transform:translateX(14px);}\n #dp-root .dp-ghost-btn,#dp-root .dp-primary-btn.dp-small {font-size:11px;padding:5px 8px;}\n #dp-root .dp-section-title,#dp-root .dp-credit {font-size:9px;}\n #dp-root .dp-list {max-height:min(140px,25vh);}\n #dp-root .dp-thumb {width:28px;height:28px;}\n #dp-root .dp-video-title {font-size:10px;}\n #dp-root .dp-num,#dp-root .dp-video-sub,#dp-root .dp-ver {font-size:9px;}\n #dp-root .dp-empty-state {padding:9px;}\n #dp-root .dp-empty-state p {font-size:10px;}\n #dp-root .dp-save-ico {width:32px;height:30px;}\n}\n#dpDownloadNotice {position:fixed;z-index:2147483647;bottom:10px;left:10px;right:10px;background:#3a0818;color:white;border:1px solid #fb7185;border-radius:10px;padding:10px;font:12px/1.4 system-ui;box-sizing:border-box;}\n";document.documentElement.appendChild(node);};
 if(document.documentElement)style();else document.addEventListener('DOMContentLoaded',style,{once:true});
// Unwatermark Dola | Content script + in-page glass dock
// Created by Alief Neutron

(function () {
  'use strict';

  // Registered in the MAIN world by GeckoView manifest.

  const CREATOR = 'Alief Neutron';
  const capturedMediaMap = new Map();
  const cardBindings = new WeakMap();
  function mediaIdentity(media){return extractTOSKey(media?.url)||media?.vid||media?.fallbackUrl||media?.url||'';}
  function cardFingerprint(card){return Array.from(card.querySelectorAll('img,video')).map(n=>n.getAttribute('poster')||n.getAttribute('src')||'').join('|');}
  function bindCard(card,media){cardBindings.set(card,{key:mediaIdentity(media),fingerprint:cardFingerprint(card)});return media;}

  let currentConfig = {
    autoDownload: false,
    notifications: true,
    subfolder: 'Dola_Pilot_Videos',
    totalDownloaded: 0
  };
  let isPanelOpen = false;

  // ---------------------------------------------------------------------------
  // Small helpers
  // ---------------------------------------------------------------------------
  const ICONS = {
    download: '<svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>',
    film: '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="3" width="20" height="18" rx="3"/><path d="M7 3v18M17 3v18M2 9h5M2 15h5M17 9h5M17 15h5"/></svg>',
    layers: '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="12 2 2 7 12 12 22 7 12 2"/><polyline points="2 17 12 22 22 17"/><polyline points="2 12 12 17 22 12"/></svg>',
    eye: '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>',
    copy: '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>',
    minus: '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><line x1="5" y1="12" x2="19" y2="12"/></svg>',
    chevron: '<svg viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 15 12 9 18 15"/></svg>',
    bolt: '<svg viewBox="0 0 24 24" width="15" height="15" fill="currentColor"><path d="M13 2 4 14h7l-1 8 9-12h-7z"/></svg>'
  };

  function el(tag, className, html) {
    const node = document.createElement(tag);
    if (className) node.className = className;
    if (html != null) node.innerHTML = html; // static markup only (ICONS / literals)
    return node;
  }

  function setText(node, text) {
    node.textContent = text;
    return node;
  }

  function flash(btn, label, cls, ms, restoreLabel) {
    const span = btn.querySelector('span') || btn;
    span.textContent = label;
    if (cls) btn.classList.add(cls);
    setTimeout(() => {
      if (cls) btn.classList.remove(cls);
      span.textContent = restoreLabel;
      btn.disabled = false;
    }, ms);
  }

  const recoveryCandidates=new Map();let recoveryActive=false,lastRecovery=0,recoveryPromise=null,lastResponseCount=0;
  function captureStatus(message){let node=document.getElementById('dpCaptureStatus');if(!node){node=document.createElement('div');node.id='dpCaptureStatus';node.style.cssText='padding:6px 8px;font:10px/1.4 system-ui;color:#fff';document.querySelector('#dp-root .dp-app')?.appendChild(node);}node.textContent=message;}
  let candidateCursor=0;
  async function resolveCaptured(items,force=false,channel='network'){
    const unique=[...new Map((items||[]).filter(v=>v?.fallbackUrl&&(!v.meta?.chatId||v.meta.chatId===currentChat())).map(v=>[v.fallbackUrl,v])).values()];
    const fresh=unique.filter(item=>!recoveryCandidates.has(item.fallbackUrl));for(const item of unique)recoveryCandidates.set(item.fallbackUrl,item);
    const pool=(force?unique:unique.filter(item=>!Array.from(capturedMediaMap.values()).some(v=>v.fallbackUrl===item.fallbackUrl&&(!item.meta?.chatId||v.chatId===item.meta.chatId)))).sort((a,b)=>Number(b.meta?.chatId===currentChat())-Number(a.meta?.chatId===currentChat()));const selected=[];for(let i=0;i<Math.min(pool.length,3);i++)selected.push(pool[(candidateCursor+i)%pool.length]);if(pool.length)candidateCursor=(candidateCursor+selected.length)%pool.length;
    await Promise.allSettled(selected.map(async item=>{try{const result=await within(chrome.runtime.sendMessage({type:'FETCH_AND_RESOLVE_FALLBACK',fallbackUrl:item.fallbackUrl,keySeed:item.keySeed||item.meta?.keySeed||'',meta:item.meta||{},force}),15000,'DOLA_RESOLVER');if(result?.media)registerMedia({...result.media,chatId:item.meta?.chatId||result.media.chatId,poster:item.meta?.poster||result.media.poster,messageId:item.meta?.messageId||result.media.messageId});else if(result?.error)lastDolaError=result.error;}catch(error){lastDolaError=error.message;}}));
    invoke('diagnostic',{stage:'chat_scoped_candidates',count:[...recoveryCandidates.values()].filter(v=>v.meta?.chatId===currentChat()).length}).catch(()=>{});invoke('diagnostic',{stage:'chat_scoped_media',count:[...capturedMediaMap.values()].filter(v=>v.chatId===currentChat()).length}).catch(()=>{});const ready=getPageOrderedVideos().filter(v=>v.resolverSource==='pc').length;captureStatus(`Sumber: ${ready} · kandidat: ${recoveryCandidates.size} · respons jaringan: ${lastResponseCount}`+(ready?'':(lastDolaError?' · '+lastDolaError:'')));invoke('diagnostic',{stage:'capture_'+channel,count:recoveryCandidates.size}).catch(()=>{});
  }
  browser.runtime.onMessage.addListener(message=>{if(message?.type==='ALIEF_DOLA_CAPTURE')resolveCaptured(message.items,false,'network').catch(()=>{});});
  function recoverSources(force=false){if(recoveryPromise)return recoveryPromise;if(!force&&Date.now()-lastRecovery<2500)return Promise.resolve();recoveryActive=true;lastRecovery=Date.now();recoveryPromise=(async()=>{try{window.postMessage({type:'ALIEF_DOLA_RESCAN_BOOTSTRAP'},location.origin);const result=await within(browser.runtime.sendMessage({type:'ALIEF_DOLA_CAPTURE_POLL'}),2000,'DOLA_CAPTURE_POLL');lastResponseCount=result?.stats?.responses||0;invoke('diagnostic',{stage:result?.stats?.filter?'capture_network_ready':'capture_network_off',count:lastResponseCount}).catch(()=>{});await resolveCaptured([...(result?.items||[]),...recoveryCandidates.values()],force,'poll');}catch(error){lastDolaError=error.message;captureStatus(error.message);}finally{recoveryActive=false;recoveryPromise=null;}})();return recoveryPromise;}
  async function getReadySource(video){
    const find=()=>{
      const key=mediaIdentity(video);if(key&&capturedMediaMap.has(key))return capturedMediaMap.get(key);
      if(video?.url&&video.resolverSource==='pc')return video;
      return getPageOrderedVideos().find(v=>v.resolverSource==='pc'&&video?.sceneIndex&&v.sceneIndex===video.sceneIndex)||null;
    };
    let ready=find();if(ready)return ready;
    showDolaNotice('Memeriksa data sumber chat…');
    await within(recoverSources(false),16500,'DOLA_CAPTURE_WAIT');ready=find();
    if(!ready){invoke('diagnostic',{stage:'source_unmatched',count:capturedMediaMap.size}).catch(()=>{});lastDolaError='Identitas video chat ini belum tertangkap. Muat ulang chat, lalu buka menu Dola. Jika tetap kosong, salin Diagnostik Dola.';}
    return ready;
  }
  recoverForAction=getReadySource;
  canUseMedia=media=>!!currentChat()&&getPageOrderedVideos().some(v=>v.resolverSource==='pc'&&mediaIdentity(v)===mediaIdentity(media));
  // Initial fetch of captured videos and config from background
  chrome.runtime.sendMessage({ type: 'GET_CAPTURED_VIDEOS' }, (res) => {
    if (chrome.runtime.lastError) return;
    if (res) {
      if (res.config) currentConfig = { ...currentConfig, ...res.config };
      if (res.videos) res.videos.forEach(v => registerMedia(v, false));
      updateDockUI();
      scheduleUpdate();
    }
  });

  initDock();
  setTimeout(()=>{const parent=document.querySelector('#dp-root .dp-app');if(parent&&!document.getElementById('dpRecover')){const button=document.createElement('button');button.id='dpRecover';button.type='button';button.textContent='Periksa ulang sumber';button.className='dp-ghost-btn';button.addEventListener('click',async event=>{event.stopPropagation();button.disabled=true;const label=button.textContent;button.textContent='Memeriksa…';try{await within(recoverSources(true),17000,'DOLA_MANUAL_RETRY');}catch(error){showDolaNotice(error.message,true);}finally{button.disabled=false;button.textContent=label;}});parent.appendChild(button);}recoverSources(false);},600);

  function registerMedia(media, shouldAttach = true) {
    if (media && media.url) {
      const key = mediaIdentity(media);
      const previous=capturedMediaMap.get(key);
      capturedMediaMap.set(key, {...previous,...media,chatId:media.chatId||previous?.chatId||'',poster:media.poster||previous?.poster||'',messageId:media.messageId||previous?.messageId||''});
      if (shouldAttach) attachDownloadButtons();
      updateDockUI();
    }
  }

  // Messages from page-interceptor (main world) -> background
  window.addEventListener('message', (event) => {
    if (event.source !== window || !event.data) return;

    if (event.data.type === 'NEUTRON_RESOLVE_FALLBACK') {
      if(event.data.meta?.chatId&&event.data.meta.chatId!==currentChat())return;
      if(event.data.fallbackUrl)recoveryCandidates.set(event.data.fallbackUrl,{fallbackUrl:event.data.fallbackUrl,keySeed:event.data.keySeed,meta:event.data.meta});
      chrome.runtime.sendMessage({
        type: 'FETCH_AND_RESOLVE_FALLBACK',
        fallbackUrl: event.data.fallbackUrl,
        keySeed: event.data.keySeed,
        meta: event.data.meta
      }, (res) => {
        if (chrome.runtime.lastError) return;
        if (res && res.ok && res.media) registerMedia(res.media);
      });
    }
  });

  // Messages from background / popup
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === 'NEW_MEDIA_RESOLVED') {
      registerMedia(message.media);
    }

    if (message.type === 'GET_PAGE_ORDERED_VIDEOS') {
      sendResponse({ videos: getPageOrderedVideos() });
      return true;
    }

    if (message.type === 'GET_DOCK_STATE') {
      const dock = document.getElementById('dp-root');
      sendResponse({ minimized: !(dock && dock.classList.contains('dp-open')) });
      return true;
    }

    if (message.type === 'TOGGLE_DOCKED_BAR') {
      const dock = document.getElementById('dp-root');
      if (dock) {
        const willOpen = !dock.classList.contains('dp-open');
        setOpen(willOpen);
        sendResponse({ minimized: !willOpen });
      }
      return true;
    }

    if (message.type === 'CONFIG_CHANGED' && message.config) {
      currentConfig = { ...currentConfig, ...message.config };
      updateDockUI();
    }
  });

  // ---------------------------------------------------------------------------
  // Video detection (logic from the reference extension, kept intact)
  // ---------------------------------------------------------------------------
  function extractTOSKey(url) {
    if (!url) return '';
    try {
      const u = new URL(url, window.location.href);
      const path = u.pathname;
      const tosMatch = path.match(/tos-[a-zA-Z0-9_-]+\/([a-zA-Z0-9_-]+)/i);
      if (tosMatch && tosMatch[1]) {
        return tosMatch[1].split('~')[0].split('.')[0];
      }
      const parts = path.split('/').filter(Boolean);
      const last = parts[parts.length - 1] || '';
      return last.split('~')[0].split('.')[0];
    } catch {
      const clean = String(url).split('?')[0];
      const match = clean.match(/tos-[a-zA-Z0-9_-]+\/([a-zA-Z0-9_-]+)/i);
      return match ? match[1].split('~')[0].split('.')[0] : '';
    }
  }

  function extractDomPrompt(card, cardIndex = 0) {
    try {
      const tableRows = document.querySelectorAll('table tbody tr');
      if (tableRows.length > cardIndex) {
        const row = tableRows[cardIndex];
        const titleEl = row.querySelector('td:nth-child(2)');
        if (titleEl) {
          const titleText = (titleEl.innerText || titleEl.textContent || '').trim();
          if (titleText) return `Scene_${cardIndex + 1}_${titleText}`;
        }
      }

      const container = card.closest('[data-container-type], [data-message-id], [class*="message"]') || card.parentElement;
      if (container) {
        const headings = container.querySelectorAll('h1, h2, h3, h4, strong');
        for (const h of headings) {
          if (h.closest('#dp-root')) continue;
          const txt = (h.innerText || h.textContent || '').trim();
          if (txt.length >= 4 && txt.length <= 80 && !txt.includes('1080P') && !txt.includes('Dola Pilot') && !txt.includes('Unwatermark Dola') && !txt.includes(CREATOR)) {
            return txt;
          }
        }
      }
    } catch (e) {}
    return `Scene ${cardIndex + 1}`;
  }

  function getVideoCards() {
    if (!document.body) return [];
    const rawCards = document.querySelectorAll('[class*="block-video"], [class*="block_video"], .image-box-grid-item-FTeESI, [class*="image-box-grid-item"]');
    const cards = [];

    rawCards.forEach((node) => {
      const block = node.querySelector('[class*="block-video"]') || node;
      if (!cards.includes(block)) cards.push(block);
    });

    const standalonePlayers = document.querySelectorAll('.video-player-wrapper, [class*="video-player-wrapper"]');
    standalonePlayers.forEach((node) => {
      if (!node.closest('[class*="block-video"], [class*="block_video"], [class*="image-box-grid-item"]')) {
        if (!cards.includes(node)) cards.push(node);
      }
    });

    return cards;
  }

  function findMatchingMediaForCard(card, allCards) {
    const allMedia = Array.from(capturedMediaMap.values()).filter(v=>!v.chatId||v.chatId===currentChat());
    if (allMedia.length === 0) return null;

    const binding=cardBindings.get(card);
    if(binding&&binding.fingerprint===cardFingerprint(card)&&capturedMediaMap.has(binding.key)&&allMedia.includes(capturedMediaMap.get(binding.key)))return capturedMediaMap.get(binding.key);
    const cardIndex = allCards.indexOf(card);
    const imgEls = card.querySelectorAll('img');
    const videoEl = card.querySelector('video');

    const domImgSrcs = [...Array.from(imgEls).flatMap(img=>[img.currentSrc,img.src,img.getAttribute('data-src')]),videoEl?.poster].filter(Boolean);
    const domVideoSrc = videoEl ? (videoEl.currentSrc || videoEl.src || videoEl.getAttribute('src') || '') : '';

    const cardKeys = [];
    domImgSrcs.forEach(src => {
      const k = extractTOSKey(src);
      if (k && k.length > 8) cardKeys.push(k);
    });
    if (domVideoSrc) {
      const vk = extractTOSKey(domVideoSrc);
      if (vk && vk.length > 8) cardKeys.push(vk);
    }

    let ancestor=card;
    for(let depth=0;ancestor&&depth<5;depth++,ancestor=ancestor.parentElement){
      const ids=['data-message-id','data-msg-id','data-video-id'].map(k=>ancestor.getAttribute(k)).filter(Boolean);
      const match=allMedia.find(m=>ids.some(id=>id===m.messageId||id===m.vid));if(match)return bindCard(card,match);
    }
    // Tier 1: exact key match
    for (const key of cardKeys) {
      for (const media of allMedia) {
        const mediaPosterKey = extractTOSKey(media.poster);
        const mediaVidKey = extractTOSKey(media.vid);
        const mediaUrlKey = extractTOSKey(media.url);
        if ((mediaPosterKey && mediaPosterKey === key) ||
            (mediaVidKey && mediaVidKey === key) ||
            (mediaUrlKey && mediaUrlKey === key)) {
          return bindCard(card,media);
        }
      }
    }

    // Tier 2: substring match
    for (const key of cardKeys) {
      for (const media of allMedia) {
        if ((media.poster && media.poster.includes(key)) ||
            (media.url && media.url.includes(key)) ||
            (media.vid && String(media.vid).includes(key))) {
          return bindCard(card,media);
        }
      }
    }

    // Tier 3: positional alignment
    // Unmatched resolved sources remain available in the menu; never guess by position.

    return null;
  }

  function sortScenes(list) {
    return list.sort((a, b) => {
      const aMatch = String(a.prompt || '').match(/Scene[_\s]*(\d+)/i);
      const bMatch = String(b.prompt || '').match(/Scene[_\s]*(\d+)/i);
      if (aMatch && bMatch) return parseInt(aMatch[1], 10) - parseInt(bMatch[1], 10);
      return (a.timestamp || 0) - (b.timestamp || 0);
    });
  }

  function normPrompt(t){return String(t||'').toLowerCase().replace(/[^a-z0-9\u00c0-\uffff]+/g,' ').trim();}
  function getPageOrderedVideos() {
    const cards = getVideoCards();
    const allMedia = Array.from(capturedMediaMap.values()).filter(v=>!v.chatId||v.chatId===currentChat());

    if (cards.length > 0) {
      const list = [];
      const pending = [];
      cards.forEach((card, idx) => {
        const matched = findMatchingMediaForCard(card, cards);
        const domPrompt = extractDomPrompt(card, idx);
        const imgEl = card.querySelector('img');
        const poster = (imgEl && (imgEl.src || imgEl.getAttribute('src'))) || (matched && matched.poster) || '';
        const url = matched?.resolverSource==='pc'?matched.url:'';
        const entry = {
          ...(matched || {}),
          url: url || (matched && matched.url) || '',
          poster: poster,
          prompt: (matched && matched.prompt && !matched.prompt.includes('Dola 1080P')) ? matched.prompt : domPrompt,
          sceneIndex: idx + 1,
          width: (matched && matched.width) || 1080,
          height: (matched && matched.height) || 1920,
          _cardText: normPrompt(card.innerText || card.textContent || '')
        };
        if (entry.resolverSource==='pc' && entry.url) list.push(entry); else pending.push(entry);
      });

      // Resolved sources that no card claimed.
      const used=new Set(list.map(mediaIdentity));
      const spare=[];
      for(const media of allMedia){if(media.resolverSource==='pc'&&media.chatId&&media.chatId===currentChat()&&!used.has(mediaIdentity(media))){spare.push(media);used.add(mediaIdentity(media));}}

      // Pass 1: pair spare sources with an unmatched card by prompt text (safe: content based).
      const leftover=[];
      for(const media of spare){
        const key=normPrompt(media.prompt).slice(0,60);
        let hit=-1;
        if(key.length>=12&&!/dola 1080p/.test(key)) hit=pending.findIndex(c=>c._cardText&&(c._cardText.includes(key)||(c.prompt&&key.includes(normPrompt(c.prompt).slice(0,60))&&normPrompt(c.prompt).length>=12)));
        if(hit>=0){const card=pending.splice(hit,1)[0];list.push({...card,...media,poster:media.poster||card.poster,sceneIndex:card.sceneIndex,prompt:media.prompt||card.prompt,width:media.width||card.width,height:media.height||card.height});}
        else leftover.push(media);
      }
      // Pass 2: sources still unpaired stand in for the cards that have no source.
      // Each spare source replaces one placeholder row, so the panel shows one row per video.
      // Its thumbnail comes from the video itself, never from a guessed card.
      for(const media of leftover){
        const replaced=pending.length?pending.shift():null;
        list.push({...media,poster:media.poster||'',unmatchedCard:true,sceneIndex:replaced?replaced.sceneIndex:(list.length+1)});
      }
      // Cards that still have no source remain visible so the user knows to replay them.
      for(const card of pending)list.push(card);
      list.forEach(v=>{delete v._cardText;});
      list.sort((a,b)=>(a.sceneIndex||0)-(b.sceneIndex||0));
      return list;
    }

    return sortScenes(allMedia.filter(v=>v.chatId&&v.chatId===currentChat()));
  }

  // ---------------------------------------------------------------------------
  // Shared download action
  // ---------------------------------------------------------------------------
  async function requestDownload(media, cb) {
    let answered=false;const finish=result=>{if(answered)return;answered=true;try{cb?.(result);}catch{}};
    try{
      if(!media?.url||media.resolverSource!=='pc')media=await within(getReadySource(media),17000,'DOLA_DOWNLOAD_SOURCE');
      if(media?.url&&!canUseMedia(media))throw Error('Video bukan bagian dari chat aktif.');
      if(!media?.url||media.resolverSource!=='pc')throw Error(lastDolaError||'URL sumber belum ditemukan. Buka Diagnostik Dola.');
      const url=new URL(media.url);if(['watermarked','watermark'].includes(url.searchParams.get('lr')))throw Error('Server masih memberikan sumber bertanda watermark.');
      showDolaNotice('Mengunduh sumber dari resolver PC…');
      const result=await within(chrome.runtime.sendMessage({type:'TRIGGER_DOWNLOAD',media}),248000,'DOLA_DOWNLOAD');
      if(!result?.ok)throw Error(result?.error||'Unduhan gagal. Periksa Diagnostik Dola.');
      currentConfig.totalDownloaded=(currentConfig.totalDownloaded||0)+1;showDolaNotice('Video tersimpan di Pustaka.');finish(result);
    }catch(error){lastDolaError=error.message;showDolaNotice(error.message,true);finish({ok:false,error:error.message});}
  }

  // ---------------------------------------------------------------------------
  // On-card glass download button
  // ---------------------------------------------------------------------------
  function attachDownloadButtons() {
    if (!document.body) return;
    const cards = getVideoCards();

    cards.forEach((card, index) => {
      const existing = card.querySelectorAll('.dp-card-btn');
      if (existing.length > 1) {
        for (let i = 1; i < existing.length; i++) existing[i].remove();
      }
      if (existing.length >= 1) return;

      const btn = el('button', 'dp-card-btn', `${ICONS.download}<span>Download</span>`);
      btn.type = 'button';
      btn.title = `Unwatermark Dola · by ${CREATOR}`;

      btn.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();

        btn.classList.add('dp-loading');
        btn.disabled = true;
        btn.querySelector('span').textContent = 'Menyimpan...';

        const allCurrentCards = getVideoCards();
        const currentCardIndex = allCurrentCards.indexOf(card);
        const targetMedia = findMatchingMediaForCard(card, allCurrentCards);
        const domPrompt = extractDomPrompt(card, currentCardIndex >= 0 ? currentCardIndex : index);

        let media = null;
        if (targetMedia && targetMedia.url) {
          media = {
            ...targetMedia,
            prompt: (targetMedia.prompt && !targetMedia.prompt.includes('Dola 1080P')) ? targetMedia.prompt : domPrompt
          };
        } else {
          // Recovery is attempted by requestDownload below.
          invoke('diagnostic',{stage:'preview_blocked'}).catch(()=>{});
        }

        if(!media)media={sceneIndex:(currentCardIndex>=0?currentCardIndex:index)+1,prompt:domPrompt};

        requestDownload(media, (res) => {
          btn.classList.remove('dp-loading');
          if (res && res.ok) flash(btn, 'Tersimpan!', 'dp-success', 2500, 'Download');
          else flash(btn, 'Gagal', 'dp-error', 2000, 'Download');
          updateDockUI();
        });
      });

      card.style.position = 'relative';
      card.appendChild(btn);
    });
  }

  // ---------------------------------------------------------------------------
  // Glass dock: collapsed pill by default, opens into the full panel
  // ---------------------------------------------------------------------------
  function initDock() {
    if (document.getElementById('dp-root')) return;

    if (!document.body) {
      if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initDock, { once: true });
      } else {
        const bodyObserver = new MutationObserver(() => {
          if (document.body) {
            bodyObserver.disconnect();
            initDock();
          }
        });
        bodyObserver.observe(document.documentElement || document, { childList: true, subtree: true });
      }
      return;
    }

    const logoUrl = chrome.runtime.getURL('icon128.png');
    const root = el('div', null);
    root.id = 'dp-root';
    root.innerHTML = `
      <div class="dp-panel" id="dpPanel">
        <div class="dp-orb dp-orb-a"></div>
        <div class="dp-orb dp-orb-b"></div>
        <div class="dp-orb dp-orb-c"></div>

        <div class="dp-app">
          <header class="dp-glass dp-header">
            <div class="dp-logo-group">
              <img class="dp-logo-img" src="${logoUrl}" alt="">
              <div>
                <div class="dp-h1">Unwatermark Dola</div>
                <div class="dp-subtitle">Created by ${CREATOR} 2026</div>
              </div>
            </div>
            <div class="dp-status"><span class="dp-status-dot"></span><span>Aktif</span></div>
          </header>

          <section class="dp-stats">
            <div class="dp-glass dp-stat"><span class="dp-stat-num" id="dpTotal">0</span><span class="dp-stat-label">Video tersimpan</span></div>
            <div class="dp-glass dp-stat"><span class="dp-stat-num" id="dpDetected">0</span><span class="dp-stat-label">Terdeteksi di chat</span></div>
          </section>

          <section class="dp-glass dp-controls">
            <div class="dp-control-row">
              <div class="dp-control-text"><strong>Auto-Save</strong><small>Simpan otomatis saat video siap</small></div>
              <label class="dp-switch"><input type="checkbox" id="dpAuto"><span class="dp-slider"></span></label>
            </div>
            <div class="dp-control-row">
              <div class="dp-control-text"><strong>Notifikasi</strong><small>Beri tahu setelah file tersimpan</small></div>
              <label class="dp-switch"><input type="checkbox" id="dpNotif" checked><span class="dp-slider"></span></label>
            </div>
            <div class="dp-control-row">
              <div class="dp-control-text"><strong>Dock di halaman</strong><small>Tampilkan / kecilkan bar di Dola</small></div>
              <button class="dp-ghost-btn" id="dpCollapse" type="button">Kecilkan</button>
            </div>
          </section>

          <div class="dp-section-title">
            <span>Master Videos</span>
            <button class="dp-primary-btn dp-small" id="dpAll" type="button" style="display:none">Download All</button>
          </div>
          <section class="dp-list" id="dpList"></section>

          <footer class="dp-credit">
            <span>Created by</span><strong>${CREATOR}</strong><span class="dp-ver">v3.4</span>
          </footer>
        </div>
      </div>

      <button class="dp-pill" id="dpPill" type="button" title="Unwatermark Dola">
        ${ICONS.bolt}
        <span class="dp-pill-count" id="dpPillCount">0</span>
      </button>
    `;
    document.body.appendChild(root);

    const autoToggle = root.querySelector('#dpAuto');
    const notifToggle = root.querySelector('#dpNotif');
    const btnAll = root.querySelector('#dpAll');
    const pill = root.querySelector('#dpPill');

    // Open / close. A drag on the pill moves it and must not toggle the panel.
    let suppressClick = false;
    pill.addEventListener('click', () => {
      if (suppressClick) { suppressClick = false; return; }
      setOpen(!isPanelOpen);
    });
    root.querySelector('#dpCollapse').addEventListener('click', () => setOpen(false));

    document.addEventListener('pointerdown', (e) => {
      if (isPanelOpen && !root.contains(e.target)) setOpen(false);
    }, true);
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && isPanelOpen) setOpen(false);
    });

    autoToggle.addEventListener('change', () => {
      currentConfig.autoDownload = autoToggle.checked;
      chrome.runtime.sendMessage({ type: 'UPDATE_CONFIG', config: { autoDownload: autoToggle.checked } });
    });
    notifToggle.addEventListener('change', () => {
      currentConfig.notifications = notifToggle.checked;
      chrome.runtime.sendMessage({ type: 'UPDATE_CONFIG', config: { notifications: notifToggle.checked } });
    });

    btnAll.addEventListener('click', async () => {
      showDolaNotice('Memeriksa sumber untuk Download All…');
      try{await within(recoverSources(true),17000,'DOLA_ALL_SOURCES');}catch(error){showDolaNotice(error.message,true);btnAll.disabled=false;return;}
      const videos = getPageOrderedVideos().filter(v => v.url&&v.resolverSource==='pc');
      if (!videos.length){showDolaNotice('Belum ada URL sumber untuk diunduh. Buka Diagnostik Dola untuk melihat penangkap data.',true);return;}
      btnAll.disabled = true;
      // stagger a little so the browser's download manager is not flooded
      videos.forEach((v, i) => setTimeout(() => requestDownload(v), i * 350));
      flash(btnAll, 'Diproses!', 'dp-ok', 2200 + videos.length * 350, `Download All (${videos.length})`);
      setTimeout(updateDockUI, 2400 + videos.length * 350);
    });

    // Always starts collapsed (pill only). Only the pill position is remembered.
    chrome.storage.local.get(['dpDockPos'], (res) => {
      if (chrome.runtime.lastError) return;
      if (res.dpDockPos) applyPos(root, res.dpDockPos.left, res.dpDockPos.top);
    });

    makeDraggable(root, pill, () => { suppressClick = true; setTimeout(() => { suppressClick = false; }, 0); });
    window.addEventListener('resize', () => { clampIntoViewport(root); if (isPanelOpen) placePanel(); });
    updateDockUI();
  }

  function setOpen(open) {
    const root = document.getElementById('dp-root');
    if (!root) return;
    isPanelOpen = !!open;
    root.classList.toggle('dp-open', isPanelOpen);
    if (isPanelOpen) {
      placePanel();
      updateDockUI();
      renderList();
    }
  }

  // Keep the panel inside the viewport: open upwards/downwards and
  // right-/left-aligned depending on where the pill currently sits.
  function placePanel() {
    const root = document.getElementById('dp-root');
    if (!root) return;
    const r = root.getBoundingClientRect();
    const panelW = 320;
    const alignLeft = (r.right - panelW) < 8;
    const openDown = r.top < 420 && (window.innerHeight - r.bottom) > r.top;
    root.classList.toggle('dp-align-left', alignLeft);
    root.classList.toggle('dp-open-down', openDown);
  }

  function applyPos(root, left, top) {
    root.style.left = left + 'px';
    root.style.top = top + 'px';
    root.style.bottom = 'auto';
    root.style.right = 'auto';
    root.classList.add('dp-moved');
    if (isPanelOpen) placePanel();
  }

  function clampIntoViewport(root) {
    if (!root.classList.contains('dp-moved')) return;
    const r = root.getBoundingClientRect();
    const left = Math.min(Math.max(0, r.left), Math.max(0, window.innerWidth - r.width));
    const top = Math.min(Math.max(0, r.top), Math.max(0, window.innerHeight - r.height));
    applyPos(root, left, top);
  }

  function makeDraggable(root, handle, onDragged) {
    let startX = 0, startY = 0, originLeft = 0, originTop = 0, down = false, dragging = false;
    const pillW = () => handle.offsetWidth, pillH = () => handle.offsetHeight;

    handle.addEventListener('pointerdown', (e) => {
      if (e.button !== 0) return;
      const r = handle.getBoundingClientRect();
      down = true; dragging = false;
      startX = e.clientX; startY = e.clientY;
      originLeft = r.left; originTop = r.top;
      handle.setPointerCapture(e.pointerId);
    });

    handle.addEventListener('pointermove', (e) => {
      if (!down) return;
      const dx = e.clientX - startX, dy = e.clientY - startY;
      if (!dragging && Math.hypot(dx, dy) < 5) return;
      if (!dragging) {
        dragging = true;
        // pin the pill's own box (not the whole root) before moving
        root.classList.add('dp-dragging');
      }
      const left = Math.min(Math.max(0, originLeft + dx), Math.max(0, window.innerWidth - pillW()));
      const top = Math.min(Math.max(0, originTop + dy), Math.max(0, window.innerHeight - pillH()));
      applyPos(root, left, top);
    });

    const end = (e) => {
      if (!down) return;
      down = false;
      try { handle.releasePointerCapture(e.pointerId); } catch {}
      if (!dragging) return;
      dragging = false;
      root.classList.remove('dp-dragging');
      onDragged && onDragged();
      const r = root.getBoundingClientRect();
      chrome.storage.local.set({ dpDockPos: { left: Math.round(r.left), top: Math.round(r.top) } });
    };
    handle.addEventListener('pointerup', end);
    handle.addEventListener('pointercancel', end);
  }

  function updateDockUI() {
    const root = document.getElementById('dp-root');
    if (!root) return;

    const videos = getPageOrderedVideos();
    const count = videos.length;

    const set = (sel, v) => { const n = root.querySelector(sel); if (n) n.textContent = v; };
    set('#dpPillCount', count);

    if (isPanelOpen) {
      set('#dpDetected', count);
      set('#dpTotal', currentConfig.totalDownloaded || 0);

      const autoToggle = root.querySelector('#dpAuto');
      if (autoToggle) autoToggle.checked = !!currentConfig.autoDownload;
      const notifToggle = root.querySelector('#dpNotif');
      if (notifToggle) notifToggle.checked = currentConfig.notifications !== false;

      const btnAll = root.querySelector('#dpAll');
      if (btnAll && !btnAll.classList.contains('dp-ok')) {
        btnAll.style.display = count > 0 ? 'inline-block' : 'none';
        btnAll.disabled = count === 0;
        btnAll.textContent = count > 0 ? `Download All (${count})` : 'Download All';
      }
      renderList(videos);
    }
  }

  const ICON_ATTR = 'viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"';
  const DL_ICON = `<svg ${ICON_ATTR}><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>`;
  const OK_ICON = `<svg ${ICON_ATTR}><polyline points="20 6 9 17 4 12"/></svg>`;
  const ERR_ICON = `<svg ${ICON_ATTR}><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>`;

  function makeThumb(video) {
    const wrap = el('div', 'dp-thumb');
    const frame = () => {
      // No usable poster: show the first frame of the resolved video itself.
      wrap.textContent = '';
      if (!video.url) { wrap.innerHTML = ICONS.film; return; }
      const v = document.createElement('video');
      v.muted = true; v.defaultMuted = true; v.playsInline = true; v.preload = 'metadata'; v.controls = false;
      v.setAttribute('muted', ''); v.setAttribute('playsinline', ''); v.setAttribute('disablepictureinpicture', '');
      v.style.cssText = 'width:100%;height:100%;object-fit:cover;display:block;pointer-events:none;';
      v.addEventListener('error', () => { v.remove(); wrap.innerHTML = ICONS.film; }, { once: true });
      v.addEventListener('loadeddata', () => { try { v.pause(); } catch {} }, { once: true });
      v.src = video.url + (video.url.includes('#') ? '' : '#t=0.1');
      wrap.appendChild(v);
    };
    if (video.poster) {
      const img = document.createElement('img');
      img.alt = '';
      img.referrerPolicy = 'no-referrer';
      img.addEventListener('error', () => { img.remove(); frame(); });
      img.src = video.poster;
      wrap.appendChild(img);
    } else {
      frame();
    }
    return wrap;
  }

  let lastListSignature='';
  function renderList(videosArg) {
    const listEl = document.getElementById('dpList');
    if (!listEl) return;

    const videos = videosArg || getPageOrderedVideos();
    const signature=JSON.stringify(videos.map(v=>[v.vid,v.url,v.prompt,v.poster,v.resolverSource,v.width,v.height]));if(signature===lastListSignature&&listEl.childNodes.length)return;lastListSignature=signature;
    listEl.textContent = '';

    if (videos.length === 0) {
      const empty = el('div', 'dp-empty-state',
        '<svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><polygon points="23 7 16 12 23 17 23 7"></polygon><rect x="1" y="5" width="15" height="14" rx="3" ry="3"></rect></svg>');
      empty.appendChild(setText(el('p'), 'Buka chat Dola yang berisi video, lalu master 1080P akan muncul di sini.'));
      listEl.appendChild(empty);
      return;
    }

    videos.forEach((video, index) => {
      const item = el('div', 'dp-video-item');
      const left = el('div', 'dp-video-left');
      left.appendChild(makeThumb(video));

      const info = el('div', 'dp-video-info');
      const title = el('div', 'dp-video-title');
      const promptTitle = video.prompt || `Scene ${index + 1} Video`;
      title.title = promptTitle;
      title.appendChild(setText(el('span', 'dp-num'), `#${video.sceneIndex || (index + 1)}`));
      title.appendChild(setText(el('span', 'dp-name'), promptTitle.replace(/_/g, ' ')));
      const res = (video.width && video.height) ? `${video.width}×${video.height}` : '1080P Master';
      info.appendChild(title);
      info.appendChild(setText(el('div', 'dp-video-sub'), video.resolverSource==='pc'?`${video.unmatchedCard?'Sumber ditemukan':'Resolver PC'} · ${res}`:'Sumber belum tertangkap · putar ulang video'));
      left.appendChild(info);

      const actions = el('div', 'dp-video-actions');

      const prev = el('button', 'dp-icon-btn', ICONS.eye);
      prev.type = 'button'; prev.title = 'Pratinjau video';
      prev.addEventListener('click', (e) => {
        e.stopPropagation();
        e.preventDefault();nativeAction('preview',video);
      });

      const copy = el('button', 'dp-icon-btn', ICONS.copy);
      copy.type = 'button'; copy.title = 'Salin link video';
      copy.addEventListener('click', async (e) => {
        e.stopPropagation();
        e.preventDefault();if(await nativeAction('copy',video)){copy.classList.add('dp-ok');setTimeout(()=>copy.classList.remove('dp-ok'),1500);}
      });

      const save = el('button', 'dp-primary-btn dp-small dp-save-ico', DL_ICON);
      save.type = 'button';
      save.title = 'Download';
      save.setAttribute('aria-label', 'Download');
      save.disabled = false;
      save.addEventListener('click', (e) => {
        e.stopPropagation();
        save.disabled = true;
        save.classList.add('dp-busy');
        requestDownload(video, (res) => {
          save.classList.remove('dp-busy');
          const ok = !!(res && res.ok);
          save.innerHTML = ok ? OK_ICON : ERR_ICON;
          save.classList.add(ok ? 'dp-ok' : 'dp-err');
          if (ok) {
            const t = document.getElementById('dpTotal');
            if (t) t.textContent = currentConfig.totalDownloaded || 0;
          }
          setTimeout(() => {
            save.innerHTML = DL_ICON;
            save.classList.remove('dp-ok', 'dp-err');
            save.disabled = false;
          }, 2000);
        });
      });

      actions.append(prev, copy, save);
      item.append(left, actions);
      listEl.appendChild(item);
    });
  }

  // Debounced DOM scanner
  let updateDebounceTimer = null;
  function scheduleUpdate() {
    if (updateDebounceTimer) return;
    updateDebounceTimer = setTimeout(() => {
      updateDebounceTimer = null;
      attachDownloadButtons();
      updateDockUI();
      if(![...capturedMediaMap.values()].some(v=>v.resolverSource==='pc'))recoverSources(false);
    }, 400);
  }

  const observer = new MutationObserver((mutations) => {
    // ignore our own UI mutations to avoid feedback loops
    for (const m of mutations) {
      const t = m.target;
      if (t && t.nodeType === 1 && t.closest && t.closest('#dp-root')) continue;
      scheduleUpdate();
      return;
    }
  });

  if (document.body) {
    observer.observe(document.body, { childList: true, subtree: true });
  } else {
    document.addEventListener('DOMContentLoaded', () => {
      if (document.body) observer.observe(document.body, { childList: true, subtree: true });
    }, { once: true });
  }

  setInterval(scheduleUpdate, 3000);
})();


}
