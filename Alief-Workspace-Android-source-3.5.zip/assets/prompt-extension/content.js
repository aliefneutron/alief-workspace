(()=>{
 const port=browser.runtime.connectNative('aliefPrompt');let target=null;
 const editable=n=>n instanceof HTMLTextAreaElement||(n instanceof HTMLInputElement&&['text','search','url','email',''].includes(n.type))||n instanceof HTMLElement&&n.isContentEditable;
 document.addEventListener('focusin',e=>{if(editable(e.target))target=e.target;},true);
 port.onMessage.addListener(m=>{
  if(m.action==='selection'){port.postMessage({type:'selection',text:String(window.getSelection()||'').slice(0,100000)});return;}
  if(m.action!=='fill')return;
  const n=editable(document.activeElement)?document.activeElement:target;let ok=false;
  if(n&&n.isConnected&&!n.disabled&&!n.readOnly&&n.getClientRects().length){
   n.focus();const text=String(m.text||'').slice(0,100000);
   if(n.isContentEditable){const selection=getSelection(),range=document.createRange();range.selectNodeContents(n);selection.removeAllRanges();selection.addRange(range);ok=document.execCommand('insertText',false,text);}
   else {const proto=n instanceof HTMLTextAreaElement?HTMLTextAreaElement.prototype:HTMLInputElement.prototype;Object.getOwnPropertyDescriptor(proto,'value').set.call(n,text);n.dispatchEvent(new InputEvent('input',{bubbles:true,inputType:'insertText',data:text}));n.dispatchEvent(new Event('change',{bubbles:true}));ok=true;}
  }
  port.postMessage({type:'fill',ok});
 });
})();