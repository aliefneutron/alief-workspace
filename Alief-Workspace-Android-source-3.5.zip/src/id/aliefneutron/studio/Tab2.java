package id.aliefneutron.studio;
public class Tab2 extends MainActivity { protected int tabNumber(){return 2;} }
