package id.aliefneutron.studio;
import android.content.*;
import android.database.*;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.provider.OpenableColumns;
import android.webkit.MimeTypeMap;
import java.io.*;
public class LibraryProvider extends ContentProvider {
 public boolean onCreate(){return true;}
 private File file(Uri u) throws FileNotFoundException {
  String n=u.getLastPathSegment();
  if(n==null||!n.matches("[a-f0-9-]+\\.[a-zA-Z0-9]{1,8}"))throw new FileNotFoundException();
  File f=new File(new File(getContext().getFilesDir(),"library"),n);
  if(!f.isFile())throw new FileNotFoundException();return f;
 }
 public String getType(Uri u){String n=u.getLastPathSegment();String ext=n==null?"":n.substring(n.lastIndexOf('.')+1);String type=MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext);return type==null?"application/octet-stream":type;}
 public ParcelFileDescriptor openFile(Uri u,String mode)throws FileNotFoundException {if(!"r".equals(mode))throw new FileNotFoundException("Read only");return ParcelFileDescriptor.open(file(u),ParcelFileDescriptor.MODE_READ_ONLY);}
 public Cursor query(Uri u,String[] projection,String selection,String[] args,String sort){try{File f=file(u);String[] columns=projection==null?new String[]{OpenableColumns.DISPLAY_NAME,OpenableColumns.SIZE}:projection;MatrixCursor c=new MatrixCursor(columns);Object[] row=new Object[columns.length];String display=f.getName();File label=new File(f.getPath()+".name");if(label.isFile())display=new String(java.nio.file.Files.readAllBytes(label.toPath()),java.nio.charset.StandardCharsets.UTF_8);for(int i=0;i<columns.length;i++)row[i]=OpenableColumns.DISPLAY_NAME.equals(columns[i])?display:OpenableColumns.SIZE.equals(columns[i])?f.length():null;c.addRow(row);return c;}catch(Exception e){return null;}}
 public Uri insert(Uri u,ContentValues v){throw new UnsupportedOperationException();}
 public int delete(Uri u,String s,String[] a){throw new UnsupportedOperationException();}
 public int update(Uri u,ContentValues v,String s,String[] a){throw new UnsupportedOperationException();}
}
