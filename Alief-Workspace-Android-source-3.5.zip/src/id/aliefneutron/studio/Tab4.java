package id.aliefneutron.studio;
public class Tab4 extends MainActivity { protected int tabNumber(){return 4;} }
