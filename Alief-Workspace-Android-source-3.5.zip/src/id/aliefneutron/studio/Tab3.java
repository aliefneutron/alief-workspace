package id.aliefneutron.studio;
public class Tab3 extends MainActivity { protected int tabNumber(){return 3;} }
