package id.aliefneutron.studio;
import android.content.Context;
import java.io.*;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import org.json.JSONObject;

/** Local, bounded diagnostics. No cookies, full URLs, signed queries, or response bodies. */
final class DolaDiagnostics {
 static synchronized void record(Context context,String stage,String url,int status){
  try{File file=new File(context.getFilesDir(),"dola-diagnostics.log");if(file.length()>64000)new FileOutputStream(file).close();JSONObject entry=new JSONObject();entry.put("time",System.currentTimeMillis());entry.put("stage",stage.replaceAll("[^a-zA-Z0-9_-]","").substring(0,Math.min(stage.replaceAll("[^a-zA-Z0-9_-]","").length(),40)));entry.put("status",status);
   try{URI uri=new URI(url);entry.put("host",uri.getHost());String query=uri.getRawQuery();if(query!=null)for(String part:query.split("&")){String[] item=part.split("=",2);if(item.length==2&&("lr".equals(item[0])||"logo_type".equals(item[0])))entry.put(item[0],item[1].replaceAll("[^a-zA-Z0-9_-]","").substring(0,Math.min(item[1].replaceAll("[^a-zA-Z0-9_-]","").length(),40)));}}catch(Exception ignored){}
   try(FileOutputStream out=new FileOutputStream(file,true)){out.write((entry.toString()+"\n").getBytes(StandardCharsets.UTF_8));}
  }catch(Exception ignored){}
 }
 static synchronized String report(Context context){try{return "Alief Workspace Android 3.5\n"+new String(java.nio.file.Files.readAllBytes(new File(context.getFilesDir(),"dola-diagnostics.log").toPath()),StandardCharsets.UTF_8);}catch(Exception e){return "Belum ada diagnostik. Buka Dola, putar video dan coba tombol ekstensi terlebih dahulu.";}}
}
