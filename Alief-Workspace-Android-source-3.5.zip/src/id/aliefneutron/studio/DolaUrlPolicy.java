package id.aliefneutron.studio;

import java.net.URI;
import java.io.IOException;
import java.util.Locale;

/** Scope native requests to Dola and its media CDN, including every redirect. */
public final class DolaUrlPolicy {
 private static final String[] CDN={"dola.com","byteintlapi.com","ibytedtos.com","byteoversea.com","byteimg.com","ibytedtos.cn","volccdn.com","doubaocdn.com","bytecdn.cn","bytescm.com","volces.com"};
 public static boolean isSite(String raw){try{URI u=new URI(raw);String h=u.getHost();return "https".equals(u.getScheme())&&u.getUserInfo()==null&&(u.getPort()==-1||u.getPort()==443)&&("dola.com".equals(h)||"www.dola.com".equals(h));}catch(Exception e){return false;}}
 public static String media(String raw)throws IOException {
  try{if(raw==null||raw.length()>16384)throw new Exception();URI u=new URI(raw);String h=u.getHost();if(h==null||u.getRawUserInfo()!=null||u.getFragment()!=null)throw new Exception();h=h.toLowerCase(Locale.ROOT);boolean allowed=false;for(String d:CDN)if(h.equals(d)||h.endsWith("."+d)){allowed=true;break;}if(!allowed)throw new Exception();
   if("http".equals(u.getScheme())&&u.getPort()==-1)return "https"+raw.substring(4);
   if(!"https".equals(u.getScheme())||(u.getPort()!=-1&&u.getPort()!=443))throw new Exception();return raw;
  }catch(Exception e){throw new IOException("Alamat media tidak didukung oleh integrasi Dola.");}
 }
}
