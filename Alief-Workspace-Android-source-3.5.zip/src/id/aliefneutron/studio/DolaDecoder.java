package id.aliefneutron.studio;
import java.util.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import javax.crypto.Cipher;
import javax.crypto.spec.*;

/** Same SHA-512/AES-CBC derivation as the PC resolver; no browser WebCrypto dependency. */
public final class DolaDecoder {
 static final String SALT="4dd4c2e6b83162090e52b3c7a6733ba41cb2462b829ab58a196b39db57177524f49baf7f08e8d68d26a72e37c1a95a2f1f05a51892aef2949732b62a38aadd58";
 static byte[] base64(String value){String text=value==null?"":value.trim();for(String candidate:new String[]{text,text.replace('$','_').replace('@','/').replace('#','.'),text.replace('$','+').replace('@','/').replace('#','=')})try{return Base64.getDecoder().decode(candidate.replace('-','+').replace('_','/'));}catch(Exception ignored){}return null;}
 static String url(byte[] bytes){if(bytes==null)return "";for(byte b:bytes){int c=b&255;if(c!=9&&c!=10&&c!=13&&(c<32||c>126))return "";}String value=new String(bytes,StandardCharsets.US_ASCII).trim();return value.startsWith("https://")||value.startsWith("http://")?value:"";}
 static String decrypt(byte[] bytes,byte[] key,byte[] iv){if(bytes.length==0||bytes.length%16!=0)return "";for(String padding:new String[]{"PKCS5Padding","NoPadding"})try{Cipher cipher=Cipher.getInstance("AES/CBC/"+padding);cipher.init(Cipher.DECRYPT_MODE,new SecretKeySpec(key,"AES"),new IvParameterSpec(iv));byte[] plain=cipher.doFinal(bytes);String value=url(plain);if(!value.isEmpty())return value;int pad=plain.length==0?0:plain[plain.length-1]&255;if(pad>0&&pad<=16&&pad<=plain.length){boolean valid=true;for(int i=plain.length-pad;i<plain.length;i++)if((plain[i]&255)!=pad)valid=false;if(valid){value=url(Arrays.copyOf(plain,plain.length-pad));if(!value.isEmpty())return value;}}}catch(Exception ignored){}return "";}
 public static String decode(String token,String keySeed){if(token==null||token.length()>100000||keySeed==null||keySeed.length()>10000)return "";String direct=token.trim();if(direct.startsWith("https://")||direct.startsWith("http://"))return direct;byte[] data=base64(token);String value=url(data);if(!value.isEmpty())return value;byte[] seed=base64(keySeed);if(data==null||seed==null||seed.length==0)return "";
  try{MessageDigest hash=MessageDigest.getInstance("SHA-512");byte[] first=hash.digest(Arrays.copyOf(seed,Math.min(seed.length,32))),salt=new byte[SALT.length()/2];for(int i=0;i<salt.length;i++)salt[i]=(byte)Integer.parseInt(SALT.substring(i*2,i*2+2),16);hash.update(first);byte[] second=hash.digest(salt),key=Arrays.copyOfRange(second,0,16),iv=Arrays.copyOfRange(second,16,32);
   if(data.length>=4&&(data[0]&255)==0xa8&&data[1]==0&&data[2]==1&&data[3]==0){value=decrypt(Arrays.copyOfRange(data,4,data.length),key,iv);if(!value.isEmpty())return value;value=decrypt(Arrays.copyOfRange(data,4,data.length),iv,key);if(!value.isEmpty())return value;if(data.length>36){value=decrypt(Arrays.copyOfRange(data,36,data.length),key,Arrays.copyOfRange(data,20,36));if(!value.isEmpty())return value;return decrypt(Arrays.copyOfRange(data,36,data.length),key,iv);}}else return decrypt(data,key,iv);
  }catch(Exception ignored){}return "";
 }
}
