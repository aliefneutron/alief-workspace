package id.aliefneutron.studio;
public class Tab5 extends MainActivity { protected int tabNumber(){return 5;} }
