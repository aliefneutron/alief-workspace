package id.aliefneutron.studio;

import android.app.Activity;
import android.content.SharedPreferences;
import android.widget.Toast;
import android.app.AlertDialog;
import android.content.*;
import android.net.Uri;
import android.graphics.Color;
import android.widget.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.atomic.AtomicInteger;
import org.json.*;
import org.mozilla.geckoview.GeckoResult;

/** Signed media transfers run outside the UI thread; raw URLs are never logged. */
final class DolaBridge {
 private final Activity activity;
 private final SharedPreferences settings;
 private final ExecutorService executor;
 private final AtomicInteger pending=new AtomicInteger();
 DolaBridge(Activity activity,String profile,ExecutorService executor){this.activity=activity;this.executor=executor;settings=activity.getSharedPreferences("dola-"+profile,0);}
 static String error(String message){JSONObject result=new JSONObject();try{result.put("error",message);}catch(Exception ignored){}return result.toString();}
 static String value(Object data)throws JSONException{return new JSONObject().put("value",data).toString();}
 GeckoResult<Object> handle(Object raw){
  if(!(raw instanceof JSONObject))return GeckoResult.fromValue(error("Rekues tidak valid."));
  JSONObject request=(JSONObject)raw;String action=request.optString("action");
  if(action.equals("decode")){String token=request.optString("token"),seed=request.optString("seed");String decoded=DolaDecoder.decode(token,seed);DolaDiagnostics.record(activity,decoded.isEmpty()?(seed.isEmpty()?"decode_seed_missing":"decode_native_failed"):"decode_native_ready","",seed.length());try{return GeckoResult.fromValue(value(decoded));}catch(Exception e){return GeckoResult.fromValue(error("Decoder gagal."));}}
  if(action.equals("copy")||action.equals("preview")){
   GeckoResult<Object> result=new GeckoResult<>();activity.runOnUiThread(()->{try{String url=DolaUrlPolicy.media(request.optString("url"));if(action.equals("copy")){((ClipboardManager)activity.getSystemService(Context.CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("Video Dola",url));Toast.makeText(activity,"Tautan video disalin.",Toast.LENGTH_SHORT).show();}else preview(url,request);DolaDiagnostics.record(activity,action,url,0);result.complete(value(true));}catch(Exception e){Toast.makeText(activity,"Tidak dapat membuka aksi video Dola.",Toast.LENGTH_LONG).show();result.complete(error("Aksi video tidak tersedia. Lihat Diagnostik Dola."));}});return result;
  }
  if(action.equals("diagnostic")){DolaDiagnostics.record(activity,request.optString("stage","extension"),request.optString("url"),request.optInt("count",0));try{return GeckoResult.fromValue(value(true));}catch(Exception e){return GeckoResult.fromValue(error("Diagnostik gagal."));}}
  if("theme".equals(action)){try{boolean b=activity.getSharedPreferences("workspace",0).getString("theme","green").equals("burgundy");return GeckoResult.fromValue(value(new JSONObject().put("name",b?"burgundy":"green").put("bg",b?"#230d17":"#101319").put("card",b?"#45172b":"#1b212b").put("accent",b?"#ff779e":"#cfff72")));}catch(Exception e){return GeckoResult.fromValue(error("Tema tidak tersedia."));}}
  if(pending.incrementAndGet()>4){pending.decrementAndGet();return GeckoResult.fromValue(error("Tunggu proses Dola yang sedang berjalan."));}
  GeckoResult<Object> result=new GeckoResult<>();
  try{executor.execute(()->{try{
   Object data;
   switch(action){
    case "get":data=new JSONObject(settings.getString("config","{}"));break;
    case "set":JSONObject incoming=request.optJSONObject("value");if(incoming==null||incoming.toString().length()>8192)throw new IOException("Pengaturan tidak valid.");JSONObject saved=new JSONObject(settings.getString("config","{}"));for(String key:new String[]{"dolaPilotConfig","dpDockPos"})if(incoming.has(key))saved.put(key,incoming.get(key));settings.edit().putString("config",saved.toString()).apply();data=true;break;
    case "fetch":DolaDiagnostics.record(activity,"resolver_start",request.optString("url"),0);data=fetch(request.optString("url"),request);break;
    case "download":activity.runOnUiThread(()->Toast.makeText(activity,"Unduhan Dola dimulai…",Toast.LENGTH_SHORT).show());DolaDiagnostics.record(activity,"download_start",request.optString("url"),0);data=download(request.optString("url"),request.optString("filename","Dola-video.mp4"),request);break;
    case "notify":data=true;break;
    default:throw new IOException("Aksi Dola tidak dikenal.");
   }
   final String response=value(data);DolaDiagnostics.record(activity,"native_reply_queued",request.optString("url"),response.length());activity.runOnUiThread(()->{result.complete(response);DolaDiagnostics.record(activity,"native_reply_completed",request.optString("url"),0);});
  }catch(Exception e){DolaDiagnostics.record(activity,action+"_failed",request.optString("url"),0);String message=e instanceof SocketTimeoutException?"Koneksi Dola melewati batas waktu. Muat ulang lalu coba lagi.":e instanceof IOException?e.getMessage():"Proses Dola gagal. Muat ulang halaman lalu coba lagi.";activity.runOnUiThread(()->Toast.makeText(activity,message,Toast.LENGTH_LONG).show());result.complete(error(message));}finally{pending.decrementAndGet();}});
  }catch(java.util.concurrent.RejectedExecutionException e){pending.decrementAndGet();result.complete(error("Tab sudah ditutup."));}
  return result;
 }
 private java.util.Map<String,String> playbackHeaders(String url,JSONObject request)throws Exception{
  java.util.HashMap<String,String> result=new java.util.HashMap<>();result.put("Referer","https://www.dola.com/");String agent=request.optString("userAgent");if(validHeader(agent,1024))result.put("User-Agent",agent);JSONObject context=request.optJSONObject("networkContext"),hosts=context==null?null:context.optJSONObject("hosts"),headers=hosts==null?null:hosts.optJSONObject(new URL(url).getHost());if(headers!=null)for(String name:new String[]{"cookie","user-agent","accept-language"}){String header=headers.optString(name);if(validHeader(header,32768))result.put(name,header);}return result;
 }
 private void preview(String url,JSONObject request)throws Exception{
  LinearLayout box=new LinearLayout(activity);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(16,16,16,16);box.setBackgroundColor(Color.rgb(16,19,25));TextView state=new TextView(activity);state.setTextColor(Color.WHITE);state.setText("Memuat pratinjau video…");box.addView(state);VideoView video=new VideoView(activity);box.addView(video,new LinearLayout.LayoutParams(-1,(int)(240*activity.getResources().getDisplayMetrics().density)));MediaController controls=new MediaController(activity);controls.setAnchorView(video);video.setMediaController(controls);AlertDialog dialog=new AlertDialog.Builder(activity).setTitle("Pratinjau Dola").setView(box).setNegativeButton("Tutup",null).create();dialog.setOnDismissListener(d->video.stopPlayback());video.setOnPreparedListener(player->{state.setVisibility(android.view.View.GONE);video.start();controls.show(0);DolaDiagnostics.record(activity,"preview_ready",url,0);});video.setOnErrorListener((player,what,extra)->{state.setText("Pratinjau gagal dimuat. Coba unduh atau periksa Diagnostik Dola.");DolaDiagnostics.record(activity,"preview_failed",url,what);return true;});dialog.show();video.setVideoURI(Uri.parse(url),playbackHeaders(url,request));
 }
 private HttpURLConnection open(String raw,JSONObject request)throws IOException {
  String next=DolaUrlPolicy.media(raw);
  for(int i=0;i<5;i++){
   if(Thread.currentThread().isInterrupted())throw new IOException("Unduhan dibatalkan.");
   URL target=new URL(next);HttpURLConnection connection=(HttpURLConnection)target.openConnection();connection.setInstanceFollowRedirects(false);boolean resolver="fetch".equals(request.optString("action"));connection.setConnectTimeout(resolver?5000:20000);connection.setReadTimeout(resolver?5000:45000);
   String referrer=request.optString("referrer");connection.setRequestProperty("Referer",DolaUrlPolicy.isSite(referrer)?referrer:"https://www.dola.com/");
   String userAgent=request.optString("userAgent");if(validHeader(userAgent,1024))connection.setRequestProperty("User-Agent",userAgent);
   JSONObject context=request.optJSONObject("networkContext"),hosts=context==null?null:context.optJSONObject("hosts"),headers=hosts==null?null:hosts.optJSONObject(target.getHost());
   if(headers!=null){for(String name:new String[]{"cookie","user-agent","accept-language"}){String header=headers.optString(name);if(validHeader(header,32768))connection.setRequestProperty(name,header);}}
   int code;
   try{code=connection.getResponseCode();}catch(IOException e){connection.disconnect();throw new IOException("Tidak dapat menghubungi server media Dola.");}
   if(code==301||code==302||code==303||code==307||code==308){String location=connection.getHeaderField("Location");connection.disconnect();if(location==null)throw new IOException("Redirect media tidak valid.");next=DolaUrlPolicy.media(new URL(new URL(next),location).toString());continue;}
   return connection;
  }throw new IOException("Terlalu banyak redirect media.");
 }
 private boolean validHeader(String value,int max){return value!=null&&!value.isEmpty()&&value.length()<=max&&value.indexOf('\r')<0&&value.indexOf('\n')<0;}
 private JSONObject fetch(String url,JSONObject request)throws Exception{
  HttpURLConnection connection=open(url,request);
  try{int code=connection.getResponseCode();DolaDiagnostics.record(activity,"resolver_response",url,code);if(code<200||code>=300)return new JSONObject().put("ok",false).put("status",code);
   ByteArrayOutputStream bytes=new ByteArrayOutputStream();try(InputStream input=connection.getInputStream()){copy(input,bytes,5L*1024*1024,10_000_000_000L);}
   DolaDiagnostics.record(activity,"resolver_body_ready",url,bytes.size());return new JSONObject().put("ok",true).put("status",code).put("bodyText",bytes.toString("UTF-8"));
  }finally{connection.disconnect();}
 }
 private String download(String url,String suggested,JSONObject request)throws Exception {
  File directory=new File(activity.getFilesDir(),"library");directory.mkdirs();File target=new File(directory,UUID.randomUUID()+".mp4"),part=new File(target.getPath()+".part");HttpURLConnection connection=open(url,request);
  try{
   int code=connection.getResponseCode();DolaDiagnostics.record(activity,"download_response",url,code);if(code==401||code==403)throw new IOException("Tautan video ditolak atau kedaluwarsa. Muat ulang video di Dola lalu coba lagi.");if(code<200||code>=300)throw new IOException("Server video merespons HTTP "+code+".");
   String mime=connection.getContentType();if(mime!=null&&(mime.contains("text/")||mime.contains("json")))throw new IOException("Respons Dola bukan file video.");
   if(connection.getContentLengthLong()>200L*1024*1024)throw new IOException("Maksimal video 200 MB.");
   try(InputStream input=connection.getInputStream();OutputStream out=new FileOutputStream(part)){copy(input,out,200L*1024*1024,240_000_000_000L);}
   if(part.length()<12)throw new IOException("Video kosong atau tidak lengkap.");
   try(RandomAccessFile check=new RandomAccessFile(part,"r")){check.seek(4);if(check.readInt()!=0x66747970)throw new IOException("File yang diterima bukan video MP4.");}
   if(!part.renameTo(target))throw new IOException("Video gagal disimpan.");String name=suggested.replaceAll("[\\\\/:*?\"<>|\\p{Cntrl}]","_");if(name.length()>160)name=name.substring(0,156)+".mp4";if(!name.endsWith(".mp4"))name+=".mp4";
   java.nio.file.Files.write(new File(target.getPath()+".name").toPath(),name.getBytes(StandardCharsets.UTF_8));
   DolaDiagnostics.record(activity,"download_saved",url,200);activity.runOnUiThread(()->Toast.makeText(activity,"Video Dola tersimpan di Pustaka.",Toast.LENGTH_LONG).show());return target.getName();
  }finally{part.delete();connection.disconnect();}
 }
 private static void copy(InputStream input,OutputStream output,long limit,long maxNanos)throws IOException{
  byte[] buffer=new byte[65536];long count=0,start=System.nanoTime();int n;
  while((n=input.read(buffer))!=-1){if(Thread.currentThread().isInterrupted())throw new IOException("Unduhan dibatalkan.");if(System.nanoTime()-start>maxNanos)throw new IOException("Transfer Dola melewati batas waktu. Coba lagi.");count+=n;if(count>limit)throw new IOException("Ukuran file melebihi batas aplikasi.");output.write(buffer,0,n);}
 }
}
